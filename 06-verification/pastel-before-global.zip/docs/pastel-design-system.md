# Mochii Pastel — bản đánh giá Design System

Bộ mới nằm trong `lib/design/pastel/`, được áp dụng vào trang Ôn tập,
các trạng thái tải/rỗng/lỗi, phiên ôn thẻ, quiz và kết quả ôn tập.
Các trang khác, màn Quản lý kiến thức và thanh điều hướng 5 tab chưa chuyển đổi.
Mã theme cũ vẫn phục vụ những màn chưa chuyển; trang Ôn tập không import bộ component cũ.

## Ngôn ngữ giao diện

- Inter đóng gói trong ứng dụng, giữ nguyên các tệp font hiện có.
- Nền pastel với vùng sáng mềm, độc lập với màu nhấn; không dùng blur nền.
- Thẻ gradient nhẹ, góc 26 px, viền sáng 1 px, bóng khuếch tán.
- Nút chính dạng viên thuốc, cao tối thiểu 54 px; nút nhỏ tối thiểu 48 px.
- Lề trang 24 px; khoảng cách 4 / 8 / 12 / 16 / 24 / 32 / 40 px.
- Nội dung đọc tối đa 680 px, tự co trên điện thoại; thống kê xếp dọc khi thiếu chỗ hoặc chữ lớn.
- Chữ chính màu mực, chữ phụ dịu hơn; màu chữ thao tác được tính từ màu nhấn để đạt tương phản tối thiểu 4.5:1 trên mặt thẻ và nền chip.
- Giữ tài nguyên robot và minh họa đang có. Không tạo hay tải hình mới.

## Màu sắc và cá nhân hóa

Nút bảng màu ở đầu tab Ôn tập mở **Không gian ôn tập**:

| Thiết lập | Lựa chọn | Lưu trữ |
| --- | --- | --- |
| Màu chủ đạo | 6 màu đang có trong hồ sơ | `ProfileModel.themePreset` |
| Nền gradient | Mây tím, Trời xanh, Đào sữa, Bạc hà | `ProfileModel.backgroundPreset` |
| Nền đơn sắc | Trắng dịu, Xám ấm | `ProfileModel.backgroundPreset` |
| Chế độ | Sáng, Tối, Hệ thống | `ProfileModel.themeMode` |

Mọi lựa chọn được lưu qua `MochiStore.save()` như các thiết lập hiện có.
Hồ sơ cũ thiếu trường nền nhận giá trị mặc định `lavender`. Khóa nền không hợp lệ
cũng hiển thị Mây tím. Nền đổi theo chế độ sáng/tối nhưng không đổi khi chọn màu nhấn.
Màu chủ đạo và chế độ sáng/tối dùng thiết lập chung hiện có của ứng dụng;
nền mới hiện chỉ được trang Ôn tập sử dụng.

## API

- `PastelTheme.build`: ThemeData riêng, Inter, ColorScheme và ThemeExtension.
- `PastelPalette`: màu nhấn gốc, màu thao tác có tương phản, mực, mặt thẻ,
  nền nhạt, viền, gradient nút/thẻ và bóng.
- `PastelBackgrounds`: danh mục và cặp màu nền sáng/tối.
- `PastelReviewScope`: ranh giới áp dụng theme; đọc hồ sơ và phản ứng trực tiếp
  khi đổi thiết lập, không thay theme của các tab khác.
- Component: `PastelScaffold`, `PastelAppBar`, `PastelCard`, `PastelSection`,
  `PastelListTile`, `PastelButton`, `PastelIconButton`, `PastelChip`,
  `PastelNoticeBanner`, `PastelProgressRing`, `PastelStatTile`, `PastelStatRow`,
  `PastelIllustration`, `PastelLoadingState`.
- `ReviewQuizCard` dùng component mới và giữ API xác thực/lưu câu trả lời hiện có.

```dart
import 'package:mochi_app/design/pastel/pastel_components.dart';

PastelCard(
  child: PastelButton(
    label: 'Bắt đầu',
    icon: Icons.play_arrow_rounded,
    expand: true,
    onPressed: start,
  ),
)
```

Các component cần đặt dưới `PastelTheme` hoặc `PastelReviewScope`.
High contrast bỏ bóng và vùng sáng trang trí; reduced motion được truyền qua
MediaQuery. Không khóa cỡ chữ của người dùng.

## Kiểm tra và ảnh xem trước

`review_theme_test.dart` kiểm tra tương phản của 6 màu × 2 chế độ, các màu nền,
khả năng lưu/đọc thiết lập và hồ sơ cũ. `pastel_preview_test.dart` kiểm tra layout
320 / 390 / 1366 px, chữ lớn 170%, đổi nền trực tiếp và giữ màu chủ đạo.
Các bài kiểm tra hành trình và khả năng phục hồi vẫn kiểm tra ôn thẻ, tự chấm,
quiz, kết quả và lỗi gateway.

Ảnh trong `docs/previews/` được render từ widget Ôn tập thực với dữ liệu kiểm thử;
không bao gồm thanh điều hướng của khung ứng dụng.

```powershell
flutter test test/review_theme_test.dart test/pastel_preview_test.dart test/review_journey_test.dart test/review_resilience_test.dart
# Xuất lại ảnh với font Inter và Material Icons:
flutter test test/pastel_preview_test.dart --dart-define=PASTEL_CAPTURE=true --update-goldens
flutter build web --base-href / --no-pub
```
