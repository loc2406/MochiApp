import 'package:flutter/material.dart';

/// Colour math shared by the design system.
abstract final class MochiContrast {
  /// Picks black or white for text drawn on [background], using the WCAG
  /// contrast ratio so yellow/cyan accents still get readable labels.
  static Color on(Color background) {
    final light = 1.05 / (background.computeLuminance() + .05);
    return light >= 4.5 ? Colors.white : const Color(0xFF171226);
  }

  static double ratio(Color a, Color b) {
    final la = a.computeLuminance(), lb = b.computeLuminance();
    return la > lb ? (la + .05) / (lb + .05) : (lb + .05) / (la + .05);
  }
}

/// Every colour the Mochi interface needs, derived from the user's accent
/// colour and the active brightness. Nothing here is hard-coded per screen:
/// swapping the accent or toggling dark mode recomputes the whole palette.
@immutable
class MochiPalette extends ThemeExtension<MochiPalette> {
  final bool isDark;
  final bool highContrast;

  /// The user's accent, unchanged, used for emphasis and icons.
  final Color accent;
  final Color onAccent;

  final Color pageTop;
  final Color pageBottom;
  final Color blobA;
  final Color blobB;

  /// Card fill, nested surface, hairline border and soft shadow.
  final Color card;
  final Color cardSoft;
  final Color cardBorder;
  final Color shadow;

  final Color ink;
  final Color muted;

  final Color gradientStart;
  final Color gradientEnd;

  /// Accent-tinted fills for icon badges, selected pills and chips.
  final Color softAccent;
  final Color accentBorder;

  final Color navBar;

  final Color success;
  final Color successSoft;
  final Color warning;
  final Color warningSoft;
  final Color danger;
  final Color dangerSoft;

  final Color chipHighBg;
  final Color chipHighFg;
  final Color chipMediumBg;
  final Color chipMediumFg;
  final Color chipLowBg;
  final Color chipLowFg;

  const MochiPalette({
    required this.isDark,
    required this.highContrast,
    required this.accent,
    required this.onAccent,
    required this.pageTop,
    required this.pageBottom,
    required this.blobA,
    required this.blobB,
    required this.card,
    required this.cardSoft,
    required this.cardBorder,
    required this.shadow,
    required this.ink,
    required this.muted,
    required this.gradientStart,
    required this.gradientEnd,
    required this.softAccent,
    required this.accentBorder,
    required this.navBar,
    required this.success,
    required this.successSoft,
    required this.warning,
    required this.warningSoft,
    required this.danger,
    required this.dangerSoft,
    required this.chipHighBg,
    required this.chipHighFg,
    required this.chipMediumBg,
    required this.chipMediumFg,
    required this.chipLowBg,
    required this.chipLowFg,
  });

  /// Soft pastel palette: the page is the accent washed into white (light) or
  /// into deep indigo (dark), cards are near-white / lifted indigo.
  factory MochiPalette.fromAccent(
    Color accent, {
    Brightness brightness = Brightness.light,
    bool highContrast = false,
  }) {
    final dark = brightness == Brightness.dark;
    Color mix(Color a, Color b, double t) => Color.lerp(a, b, t)!;

    final pageTop = dark
        ? mix(const Color(0xFF141122), accent, highContrast ? .04 : .10)
        : mix(accent, Colors.white, highContrast ? .96 : .925);
    final pageBottom = dark
        ? const Color(0xFF0E0C17)
        : mix(accent, Colors.white, highContrast ? .985 : .965);

    final card = dark
        ? mix(const Color(0xFF1F1A2E), accent, highContrast ? .04 : .09)
        : mix(Colors.white, accent, .018);
    final cardSoft = dark
        ? mix(card, Colors.white, .05)
        : mix(accent, Colors.white, .93);

    final ink = dark
        ? mix(const Color(0xFFF4F0FF), accent, .05)
        : mix(const Color(0xFF1C1533), accent, .12);
    final muted = dark ? mix(ink, pageTop, .44) : mix(ink, pageTop, .5);

    final borderBase = dark ? Colors.white : mix(Colors.white, accent, .08);
    final cardBorder = borderBase.withValues(alpha: dark ? .08 : .85);

    final softAccent = dark
        ? mix(card, accent, .24)
        : mix(accent, Colors.white, .88);
    final accentBorder = accent.withValues(alpha: dark ? .34 : .22);

    final success = dark ? const Color(0xFF4ADE80) : const Color(0xFF16A34A);
    final warning = dark ? const Color(0xFFFBBF24) : const Color(0xFFD97706);
    final danger = dark ? const Color(0xFFFB7185) : const Color(0xFFE11D48);

    Color softOf(Color tone) =>
        dark ? mix(card, tone, .22) : mix(tone, Colors.white, .86);

    final chipHigh = dark ? const Color(0xFFFDA4AF) : const Color(0xFFBE123C);
    final chipMedium = dark ? const Color(0xFFFCD34D) : const Color(0xFFB45309);
    final chipLow = dark ? const Color(0xFF86EFAC) : const Color(0xFF15803D);

    return MochiPalette(
      isDark: dark,
      highContrast: highContrast,
      accent: accent,
      onAccent: MochiContrast.on(accent),
      pageTop: pageTop,
      pageBottom: pageBottom,
      blobA: accent.withValues(alpha: highContrast ? 0 : (dark ? .16 : .20)),
      blobB: mix(
        accent,
        const Color(0xFFFF8FB1),
        .6,
      ).withValues(alpha: highContrast ? 0 : (dark ? .12 : .16)),
      card: card,
      cardSoft: cardSoft,
      cardBorder: cardBorder,
      shadow: highContrast
          ? Colors.transparent
          : (dark ? Colors.black : mix(ink, accent, .4)).withValues(
              alpha: dark ? .35 : .07,
            ),
      ink: ink,
      muted: muted,
      gradientStart: dark ? mix(accent, Colors.white, .12) : accent,
      gradientEnd: dark
          ? mix(accent, Colors.white, .34)
          : mix(accent, Colors.white, .24),
      softAccent: softAccent,
      accentBorder: accentBorder,
      navBar: dark ? mix(card, Colors.white, .04) : Colors.white,
      success: success,
      successSoft: softOf(success),
      warning: warning,
      warningSoft: softOf(warning),
      danger: danger,
      dangerSoft: softOf(danger),
      chipHighBg: dark
          ? mix(card, const Color(0xFFF43F5E), .24)
          : const Color(0xFFFFE4E9),
      chipHighFg: chipHigh,
      chipMediumBg: dark
          ? mix(card, const Color(0xFFF59E0B), .24)
          : const Color(0xFFFEF3C7),
      chipMediumFg: chipMedium,
      chipLowBg: dark
          ? mix(card, const Color(0xFF22C55E), .22)
          : const Color(0xFFDCFCE7),
      chipLowFg: chipLow,
    );
  }

  static MochiPalette of(BuildContext context) {
    final theme = Theme.of(context);
    return theme.extension<MochiPalette>() ??
        MochiPalette.fromAccent(
          const Color(0xFF7C6AF0),
          brightness: theme.brightness,
        );
  }

  LinearGradient get primaryGradient => LinearGradient(
    colors: [gradientStart, gradientEnd],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  List<BoxShadow> cardShadow({double opacity = 1}) => highContrast
      ? const []
      : [
          BoxShadow(
            color: shadow.withValues(alpha: shadow.a * opacity),
            blurRadius: 24,
            offset: const Offset(0, 10),
            spreadRadius: -6,
          ),
        ];

  List<BoxShadow> get glow => highContrast
      ? const []
      : [
          BoxShadow(
            color: accent.withValues(alpha: .32),
            blurRadius: 20,
            offset: const Offset(0, 8),
            spreadRadius: -4,
          ),
        ];

  @override
  MochiPalette copyWith({bool? highContrast}) => MochiPalette(
    isDark: isDark,
    highContrast: highContrast ?? this.highContrast,
    accent: accent,
    onAccent: onAccent,
    pageTop: pageTop,
    pageBottom: pageBottom,
    blobA: blobA,
    blobB: blobB,
    card: card,
    cardSoft: cardSoft,
    cardBorder: cardBorder,
    shadow: shadow,
    ink: ink,
    muted: muted,
    gradientStart: gradientStart,
    gradientEnd: gradientEnd,
    softAccent: softAccent,
    accentBorder: accentBorder,
    navBar: navBar,
    success: success,
    successSoft: successSoft,
    warning: warning,
    warningSoft: warningSoft,
    danger: danger,
    dangerSoft: dangerSoft,
    chipHighBg: chipHighBg,
    chipHighFg: chipHighFg,
    chipMediumBg: chipMediumBg,
    chipMediumFg: chipMediumFg,
    chipLowBg: chipLowBg,
    chipLowFg: chipLowFg,
  );

  @override
  MochiPalette lerp(covariant MochiPalette? other, double t) {
    if (other == null) return this;
    Color l(Color a, Color b) => Color.lerp(a, b, t)!;
    return MochiPalette(
      isDark: t < .5 ? isDark : other.isDark,
      highContrast: t < .5 ? highContrast : other.highContrast,
      accent: l(accent, other.accent),
      onAccent: l(onAccent, other.onAccent),
      pageTop: l(pageTop, other.pageTop),
      pageBottom: l(pageBottom, other.pageBottom),
      blobA: l(blobA, other.blobA),
      blobB: l(blobB, other.blobB),
      card: l(card, other.card),
      cardSoft: l(cardSoft, other.cardSoft),
      cardBorder: l(cardBorder, other.cardBorder),
      shadow: l(shadow, other.shadow),
      ink: l(ink, other.ink),
      muted: l(muted, other.muted),
      gradientStart: l(gradientStart, other.gradientStart),
      gradientEnd: l(gradientEnd, other.gradientEnd),
      softAccent: l(softAccent, other.softAccent),
      accentBorder: l(accentBorder, other.accentBorder),
      navBar: l(navBar, other.navBar),
      success: l(success, other.success),
      successSoft: l(successSoft, other.successSoft),
      warning: l(warning, other.warning),
      warningSoft: l(warningSoft, other.warningSoft),
      danger: l(danger, other.danger),
      dangerSoft: l(dangerSoft, other.dangerSoft),
      chipHighBg: l(chipHighBg, other.chipHighBg),
      chipHighFg: l(chipHighFg, other.chipHighFg),
      chipMediumBg: l(chipMediumBg, other.chipMediumBg),
      chipMediumFg: l(chipMediumFg, other.chipMediumFg),
      chipLowBg: l(chipLowBg, other.chipLowBg),
      chipLowFg: l(chipLowFg, other.chipLowFg),
    );
  }
}
