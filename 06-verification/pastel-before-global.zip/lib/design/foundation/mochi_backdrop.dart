import 'package:flutter/material.dart';

import 'mochi_palette.dart';

/// How the app paints the page behind the content.
enum MochiBackdropKind { gradient, solid, image }

/// Runtime backdrop configuration. The gradient is always derived from the
/// user's accent; an image can replace it (with a scrim for readability).
@immutable
class MochiBackdrop {
  final MochiBackdropKind kind;
  final ImageProvider? image;
  final double scrim;
  final double blobs;

  const MochiBackdrop({
    this.kind = MochiBackdropKind.gradient,
    this.image,
    this.scrim = .55,
    this.blobs = 1,
  }) : assert(scrim >= 0 && scrim <= 1);

  const MochiBackdrop.image(ImageProvider this.image, {this.scrim = .55})
    : kind = MochiBackdropKind.image,
      blobs = 1;

  const MochiBackdrop.solid()
    : kind = MochiBackdropKind.solid,
      image = null,
      scrim = .55,
      blobs = 0;

  MochiBackdrop copyWith({
    MochiBackdropKind? kind,
    ImageProvider? image,
    double? scrim,
    double? blobs,
  }) => MochiBackdrop(
    kind: kind ?? this.kind,
    image: image ?? this.image,
    scrim: scrim ?? this.scrim,
    blobs: blobs ?? this.blobs,
  );

  @override
  bool operator ==(Object other) =>
      other is MochiBackdrop &&
      other.kind == kind &&
      other.image == image &&
      other.scrim == scrim &&
      other.blobs == blobs;

  @override
  int get hashCode => Object.hash(kind, image, scrim, blobs);
}

/// Accessibility and background preferences carried by the theme. Screens and
/// components read it instead of poking at the profile model.
@immutable
class MochiVisuals extends ThemeExtension<MochiVisuals> {
  final bool highContrast;
  final bool reduceMotion;
  final bool haptics;
  final MochiBackdrop backdrop;

  const MochiVisuals({
    this.highContrast = false,
    this.reduceMotion = false,
    this.haptics = true,
    this.backdrop = const MochiBackdrop(),
  });

  static MochiVisuals of(BuildContext context) =>
      Theme.of(context).extension<MochiVisuals>() ?? const MochiVisuals();

  @override
  MochiVisuals copyWith({
    bool? highContrast,
    bool? reduceMotion,
    bool? haptics,
    MochiBackdrop? backdrop,
  }) => MochiVisuals(
    highContrast: highContrast ?? this.highContrast,
    reduceMotion: reduceMotion ?? this.reduceMotion,
    haptics: haptics ?? this.haptics,
    backdrop: backdrop ?? this.backdrop,
  );

  @override
  MochiVisuals lerp(covariant MochiVisuals? other, double t) =>
      other == null || t < .5 ? this : other;
}

/// Paints the accent-derived gradient plus two soft blobs, or a wallpaper with
/// a readable scrim. No blur filters: blobs are radial gradients, which keeps
/// scrolling cheap on low-end phones.
class MochiBackground extends StatelessWidget {
  final Widget child;
  final MochiBackdrop? backdrop;
  const MochiBackground({super.key, required this.child, this.backdrop});

  @override
  Widget build(BuildContext context) {
    final palette = MochiPalette.of(context);
    final config = backdrop ?? MochiVisuals.of(context).backdrop;
    final showBlobs = config.blobs > 0 && !palette.highContrast;

    return Stack(
      fit: StackFit.expand,
      children: [
        DecoratedBox(
          decoration: BoxDecoration(
            gradient: config.kind == MochiBackdropKind.solid
                ? null
                : LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [palette.pageTop, palette.pageBottom],
                  ),
            color: config.kind == MochiBackdropKind.solid
                ? palette.pageTop
                : null,
          ),
        ),
        if (config.kind == MochiBackdropKind.image && config.image != null) ...[
          ExcludeSemantics(
            child: Image(
              image: config.image!,
              fit: BoxFit.cover,
              errorBuilder: (_, _, _) => const SizedBox.expand(),
            ),
          ),
          ColoredBox(color: palette.pageTop.withValues(alpha: config.scrim)),
        ],
        if (showBlobs) ...[
          Positioned(
            top: -90,
            right: -70,
            child: _Blob(color: palette.blobA, size: 280),
          ),
          Positioned(
            top: 210,
            left: -120,
            child: _Blob(color: palette.blobB, size: 320),
          ),
          Positioned(
            bottom: -140,
            right: -60,
            child: _Blob(color: palette.blobA, size: 260),
          ),
        ],
        child,
      ],
    );
  }
}

class _Blob extends StatelessWidget {
  final Color color;
  final double size;
  const _Blob({required this.color, required this.size});

  @override
  Widget build(BuildContext context) => IgnorePointer(
    child: Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(colors: [color, color.withValues(alpha: 0)]),
      ),
    ),
  );
}
