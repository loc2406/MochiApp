import 'package:flutter/material.dart';

import '../foundation/mochi_backdrop.dart';
import '../foundation/mochi_palette.dart';
import '../foundation/mochi_tokens.dart';
import '../foundation/mochi_typography.dart';
import 'mochi_presets.dart';

/// Builds the Mochi theme from the user's accent colour.
///
/// Every surface, text colour and semantic tint is computed from the accent, so
/// switching preset or light/dark mode restyles the whole app without any
/// screen-level special cases.
abstract final class MochiTheme {
  static ThemeData light({
    Color? accent,
    MochiVisuals visuals = const MochiVisuals(),
  }) => build(
    accent: accent ?? MochiPresets.electricViolet,
    brightness: Brightness.light,
    visuals: visuals,
  );

  static ThemeData dark({
    Color? accent,
    MochiVisuals visuals = const MochiVisuals(),
  }) => build(
    accent: accent ?? MochiPresets.electricViolet,
    brightness: Brightness.dark,
    visuals: visuals,
  );

  static ThemeMode modeFrom(String? stored) => switch (stored) {
    'light' => ThemeMode.light,
    'dark' => ThemeMode.dark,
    _ => ThemeMode.system,
  };

  static ThemeData build({
    required Color accent,
    required Brightness brightness,
    MochiVisuals visuals = const MochiVisuals(),
  }) {
    final palette = MochiPalette.fromAccent(
      accent,
      brightness: brightness,
      highContrast: visuals.highContrast,
    );
    final scheme = _scheme(palette, brightness);
    final text = MochiType.textTheme(palette.ink, palette.muted);
    final base = ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      fontFamily: MochiType.family,
      brightness: brightness,
    );

    return base.copyWith(
      textTheme: text,
      primaryTextTheme: text,
      scaffoldBackgroundColor: Colors.transparent,
      canvasColor: palette.pageTop,
      dividerTheme: DividerThemeData(
        color: palette.cardBorder,
        thickness: 1,
        space: MochiSpacing.md,
      ),
      iconTheme: IconThemeData(color: palette.ink, size: MochiIconSize.md),
      appBarTheme: AppBarTheme(
        backgroundColor: Colors.transparent,
        foregroundColor: palette.ink,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        centerTitle: false,
        iconTheme: IconThemeData(color: palette.ink, size: MochiIconSize.md),
        titleTextStyle: MochiType.pageTitle(palette.ink),
      ),
      snackBarTheme: SnackBarThemeData(
        backgroundColor: palette.ink,
        contentTextStyle: text.bodyMedium?.copyWith(
          color: palette.pageTop,
          fontWeight: FontWeight.w600,
        ),
        actionTextColor: palette.gradientEnd,
        behavior: SnackBarBehavior.floating,
        elevation: 0,
        shape: const RoundedRectangleBorder(
          borderRadius: MochiRadius.controlBorder,
        ),
      ),
      dialogTheme: DialogThemeData(
        backgroundColor: palette.card,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        shape: const RoundedRectangleBorder(
          borderRadius: MochiRadius.sheetBorder,
        ),
        titleTextStyle: text.titleLarge,
        contentTextStyle: text.bodyMedium,
        actionsPadding: const EdgeInsetsDirectional.fromSTEB(
          MochiSpacing.lg,
          0,
          MochiSpacing.lg,
          MochiSpacing.md,
        ),
      ),
      bottomSheetTheme: BottomSheetThemeData(
        backgroundColor: palette.card,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        showDragHandle: true,
        dragHandleColor: palette.muted.withValues(alpha: .35),
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(
            top: Radius.circular(MochiRadius.sheet),
          ),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: palette.cardSoft,
        hintStyle: text.bodyMedium?.copyWith(color: palette.muted),
        labelStyle: text.labelLarge?.copyWith(color: palette.muted),
        contentPadding: const EdgeInsets.symmetric(
          horizontal: MochiSpacing.md,
          vertical: MochiSpacing.md,
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(18),
          borderSide: BorderSide(color: palette.cardBorder),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(18),
          borderSide: BorderSide(color: palette.cardBorder),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(18),
          borderSide: BorderSide(color: palette.accent, width: 1.6),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(18),
          borderSide: BorderSide(color: palette.danger),
        ),
        focusedErrorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(18),
          borderSide: BorderSide(color: palette.danger, width: 1.6),
        ),
      ),
      switchTheme: SwitchThemeData(
        thumbColor: WidgetStateProperty.resolveWith(
          (states) => states.contains(WidgetState.selected)
              ? Colors.white
              : palette.muted,
        ),
        trackColor: WidgetStateProperty.resolveWith(
          (states) => states.contains(WidgetState.selected)
              ? palette.accent
              : palette.cardSoft,
        ),
        trackOutlineColor: const WidgetStatePropertyAll(Colors.transparent),
        trackOutlineWidth: const WidgetStatePropertyAll(0),
      ),
      checkboxTheme: CheckboxThemeData(
        fillColor: WidgetStateProperty.resolveWith(
          (states) => states.contains(WidgetState.selected)
              ? palette.accent
              : Colors.transparent,
        ),
        checkColor: WidgetStatePropertyAll(palette.onAccent),
        side: BorderSide(
          color: palette.muted.withValues(alpha: .6),
          width: 1.6,
        ),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
      ),
      radioTheme: RadioThemeData(
        fillColor: WidgetStateProperty.resolveWith(
          (states) => states.contains(WidgetState.selected)
              ? palette.accent
              : palette.muted,
        ),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: palette.accent,
          foregroundColor: palette.onAccent,
          minimumSize: const Size(0, 52),
          padding: const EdgeInsets.symmetric(horizontal: MochiSpacing.xl),
          shape: const StadiumBorder(),
          textStyle: MochiType.button(palette.onAccent),
          elevation: 0,
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: palette.accent,
          backgroundColor: palette.card,
          minimumSize: const Size(0, 52),
          padding: const EdgeInsets.symmetric(horizontal: MochiSpacing.xl),
          side: BorderSide(color: palette.accentBorder),
          shape: const StadiumBorder(),
          textStyle: MochiType.button(palette.accent),
        ),
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          foregroundColor: palette.accent,
          textStyle: MochiType.button(palette.accent),
          shape: const StadiumBorder(),
        ),
      ),
      textSelectionTheme: TextSelectionThemeData(
        cursorColor: palette.accent,
        selectionColor: palette.accent.withValues(alpha: .25),
        selectionHandleColor: palette.accent,
      ),
      progressIndicatorTheme: ProgressIndicatorThemeData(
        color: palette.accent,
        linearTrackColor: palette.softAccent,
        circularTrackColor: palette.softAccent,
      ),
      chipTheme: ChipThemeData(
        backgroundColor: palette.softAccent,
        side: BorderSide.none,
        shape: const StadiumBorder(),
        labelStyle: text.labelMedium?.copyWith(color: palette.accent),
        padding: const EdgeInsets.symmetric(
          horizontal: MochiSpacing.sm,
          vertical: 6,
        ),
      ),
      tooltipTheme: TooltipThemeData(
        decoration: BoxDecoration(
          color: palette.ink,
          borderRadius: BorderRadius.circular(MochiRadius.badge),
        ),
        textStyle: MochiType.button(palette.pageTop).copyWith(fontSize: 12),
        waitDuration: const Duration(milliseconds: 350),
      ),
      extensions: [palette, visuals],
    );
  }

  static ColorScheme _scheme(MochiPalette palette, Brightness brightness) {
    final seeded = ColorScheme.fromSeed(
      seedColor: palette.accent,
      brightness: brightness,
    );
    return seeded.copyWith(
      primary: palette.accent,
      onPrimary: palette.onAccent,
      primaryContainer: palette.softAccent,
      onPrimaryContainer: palette.ink,
      secondary: palette.gradientEnd,
      onSecondary: palette.onAccent,
      secondaryContainer: palette.softAccent,
      onSecondaryContainer: palette.ink,
      tertiary: palette.chipMediumFg,
      onTertiary: palette.onAccent,
      tertiaryContainer: palette.chipMediumBg,
      onTertiaryContainer: palette.chipMediumFg,
      surface: palette.card,
      onSurface: palette.ink,
      onSurfaceVariant: palette.muted,
      outline: palette.muted.withValues(alpha: .45),
      outlineVariant: palette.cardBorder,
      error: palette.danger,
      onError: Colors.white,
      errorContainer: palette.dangerSoft,
      onErrorContainer: palette.danger,
      surfaceContainerLowest: palette.pageBottom,
      surfaceContainerLow: palette.cardSoft,
      surfaceContainer: palette.card,
      surfaceContainerHigh: palette.card,
      surfaceContainerHighest: palette.cardSoft,
      surfaceTint: Colors.transparent,
      shadow: palette.shadow,
      scrim: Colors.black,
      inverseSurface: palette.ink,
      onInverseSurface: palette.pageBottom,
      inversePrimary: palette.gradientEnd,
    );
  }
}
