import 'package:flutter/material.dart';

import '../foundation/mochi_palette.dart';
import '../foundation/mochi_tokens.dart';
import '../foundation/mochi_typography.dart';
import 'mochi_haptics.dart';

enum MochiButtonVariant { primary, secondary, ghost, danger }

enum MochiButtonSize { medium, small }

/// Pill button. Primary uses the accent gradient with a soft glow, secondary
/// is a white card with accent text, ghost is text-only and danger is for
/// destructive confirmation.
class MochiButton extends StatelessWidget {
  final String label;
  final VoidCallback? onPressed;
  final IconData? icon;
  final MochiButtonVariant variant;
  final MochiButtonSize size;
  final bool expand;
  final bool loading;
  final String? semanticLabel;

  const MochiButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.icon,
    this.variant = MochiButtonVariant.primary,
    this.size = MochiButtonSize.medium,
    this.expand = false,
    this.loading = false,
    this.semanticLabel,
  });

  @override
  Widget build(BuildContext context) {
    final palette = MochiPalette.of(context);
    final enabled = onPressed != null && !loading;
    final height = size == MochiButtonSize.small ? 40.0 : 52.0;
    final horizontal = size == MochiButtonSize.small
        ? MochiSpacing.md
        : MochiSpacing.xl;

    final (
      Color background,
      Color foreground,
      Gradient? gradient,
    ) = switch (variant) {
      MochiButtonVariant.primary => (
        palette.accent,
        palette.onAccent,
        palette.primaryGradient,
      ),
      MochiButtonVariant.secondary => (palette.card, palette.accent, null),
      MochiButtonVariant.ghost => (Colors.transparent, palette.accent, null),
      MochiButtonVariant.danger => (palette.danger, Colors.white, null),
    };

    final foregroundColor = enabled ? foreground : palette.muted;
    final shape = StadiumBorder(
      side: variant == MochiButtonVariant.secondary
          ? BorderSide(color: palette.accentBorder)
          : BorderSide.none,
    );

    Widget content = Row(
      mainAxisSize: expand ? MainAxisSize.max : MainAxisSize.min,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        if (loading)
          SizedBox(
            width: 17,
            height: 17,
            child: CircularProgressIndicator(
              strokeWidth: 2.2,
              valueColor: AlwaysStoppedAnimation(foregroundColor),
            ),
          )
        else if (icon != null)
          Icon(icon, size: MochiIconSize.sm, color: foregroundColor),
        if (loading || icon != null) const SizedBox(width: MochiSpacing.xs),
        Flexible(
          child: Text(
            label,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            textAlign: TextAlign.center,
            style: MochiType.button(foregroundColor)
                .copyWith(fontSize: size == MochiButtonSize.small ? 13.5 : 15),
          ),
        ),
      ],
    );

    return Semantics(
      button: true,
      enabled: enabled,
      label: semanticLabel ?? label,
      child: AnimatedOpacity(
        duration: MochiMotion.of(context, MochiMotion.quick),
        opacity: enabled ? 1 : .55,
        child: Container(
          height: height,
          decoration: BoxDecoration(
            color: gradient == null ? background : null,
            gradient: enabled ? gradient : null,
            borderRadius: MochiRadius.pillBorder,
            boxShadow: variant == MochiButtonVariant.primary && enabled
                ? palette.glow
                : const [],
          ),
          child: Material(
            type: MaterialType.transparency,
            child: InkWell(
              onTap: enabled
                  ? () {
                      MochiHaptics.tap(context);
                      onPressed!();
                    }
                  : null,
              customBorder: shape,
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: horizontal),
                child: content,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// Circular icon action used in app bars and card headers.
class MochiIconButton extends StatelessWidget {
  final IconData icon;
  final String tooltip;
  final VoidCallback? onPressed;
  final double size;
  final bool filled;
  final Color? color;
  final Color? background;

  const MochiIconButton({
    super.key,
    required this.icon,
    required this.tooltip,
    this.onPressed,
    this.size = 44,
    this.filled = true,
    this.color,
    this.background,
  });

  @override
  Widget build(BuildContext context) {
    final palette = MochiPalette.of(context);
    final tint = color ?? palette.accent;
    return IconButton(
      tooltip: tooltip,
      onPressed: onPressed == null
          ? null
          : () {
              MochiHaptics.tap(context);
              onPressed!();
            },
      style: IconButton.styleFrom(
        backgroundColor: filled
            ? (background ?? palette.card)
            : Colors.transparent,
        foregroundColor: onPressed == null ? palette.muted : tint,
        disabledForegroundColor: palette.muted,
        minimumSize: Size(size, size),
        maximumSize: Size(size, size),
        padding: EdgeInsets.zero,
        shape: const CircleBorder(),
        side: filled ? BorderSide(color: palette.cardBorder) : BorderSide.none,
      ),
      icon: Icon(icon, size: MochiIconSize.md),
    );
  }
}
