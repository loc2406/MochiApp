import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/database/mochi_store.dart';
import '../theme/mochi_presets.dart';
import 'pastel_components.dart';

/// Preview boundary: the other four tabs retain their current presentation.
class PastelReviewScope extends StatelessWidget {
  final Widget child;
  const PastelReviewScope({super.key, required this.child});
  @override
  Widget build(BuildContext context) {
    final profile = context.watch<MochiStore>().profile;
    final brightness = switch (profile.themeMode) {
      'light' => Brightness.light,
      'dark' => Brightness.dark,
      _ => MediaQuery.platformBrightnessOf(context),
    };
    return Theme(
      data: PastelTheme.build(
        accent: MochiPresets.accentFor(profile.themePreset),
        brightness: brightness,
        highContrast: profile.highContrast,
      ),
      child: MediaQuery(
        data: MediaQuery.of(context).copyWith(
          disableAnimations:
              profile.reducedMotion || MediaQuery.disableAnimationsOf(context),
        ),
        child: child,
      ),
    );
  }
}

Future<void> showPastelAppearance(BuildContext context) =>
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (_) => const PastelReviewScope(child: _AppearancePanel()),
    );

class _AppearancePanel extends StatelessWidget {
  const _AppearancePanel();
  @override
  Widget build(BuildContext context) {
    final store = context.watch<MochiStore>();
    final profile = store.profile;
    final p = PastelPalette.of(context);
    return Material(
      color: p.surface,
      borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
      child: ConstrainedBox(
        constraints: BoxConstraints(
          maxHeight: MediaQuery.sizeOf(context).height * .88,
        ),
        child: SingleChildScrollView(
          padding: EdgeInsets.fromLTRB(
            24,
            12,
            24,
            24 + MediaQuery.paddingOf(context).bottom,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisSize: MainAxisSize.min,
            children: [
              Center(
                child: Container(
                  width: 36,
                  height: 4,
                  decoration: BoxDecoration(
                    color: p.muted.withValues(alpha: .3),
                    borderRadius: BorderRadius.circular(4),
                  ),
                ),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: Text(
                      'Không gian ôn tập',
                      style: Theme.of(context).textTheme.headlineSmall,
                    ),
                  ),
                  IconButton(
                    tooltip: 'Đóng tùy chỉnh',
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.close),
                  ),
                ],
              ),
              Text(
                'Màu nền độc lập với màu chủ đạo. Lựa chọn được tự động lưu.',
                style: Theme.of(context).textTheme.bodySmall,
              ),
              const SizedBox(height: 24),
              Text(
                'Màu chủ đạo',
                style: Theme.of(context).textTheme.titleMedium,
              ),
              const SizedBox(height: 12),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (final entry in MochiPresets.colors.entries)
                    ChoiceChip(
                      label: Text(MochiPresets.labelFor(entry.key)),
                      avatar: CircleAvatar(
                        backgroundColor: entry.value,
                        radius: 8,
                      ),
                      selected: profile.themePreset == entry.key,
                      onSelected: (selected) {
                        if (!selected) return;
                        profile.themePreset = entry.key;
                        store.save();
                      },
                    ),
                ],
              ),
              const SizedBox(height: 24),
              Text(
                'Màu nền & gradient',
                style: Theme.of(context).textTheme.titleMedium,
              ),
              const SizedBox(height: 12),
              Wrap(
                spacing: 10,
                runSpacing: 10,
                children: [
                  for (final entry in PastelBackgrounds.labels.entries)
                    Semantics(
                      selected: profile.backgroundPreset == entry.key,
                      child: SizedBox(
                        width: 140,
                        child: Material(
                          clipBehavior: Clip.antiAlias,
                          borderRadius: BorderRadius.circular(18),
                          child: Ink(
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: PastelBackgrounds.colors(
                                  entry.key,
                                  p.dark,
                                ),
                              ),
                              borderRadius: BorderRadius.circular(18),
                              border: Border.all(
                                color: profile.backgroundPreset == entry.key
                                    ? p.action
                                    : p.border,
                                width: 2,
                              ),
                            ),
                            child: InkWell(
                              onTap: () {
                                profile.backgroundPreset = entry.key;
                                store.save();
                              },
                              child: Padding(
                                padding: const EdgeInsets.all(14),
                                child: Row(
                                  children: [
                                    Expanded(
                                      child: Text(
                                        entry.value,
                                        style: TextStyle(
                                          color: p.ink,
                                          fontSize: 12,
                                          fontWeight: FontWeight.w600,
                                        ),
                                      ),
                                    ),
                                    if (profile.backgroundPreset == entry.key)
                                      Icon(
                                        Icons.check_circle,
                                        size: 18,
                                        color: p.action,
                                      ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 24),
              Text(
                'Chế độ hiển thị',
                style: Theme.of(context).textTheme.titleMedium,
              ),
              const SizedBox(height: 12),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (final entry in const {
                    'light': 'Sáng',
                    'dark': 'Tối',
                    'system': 'Hệ thống',
                  }.entries)
                    ChoiceChip(
                      label: Text(entry.value),
                      selected: profile.themeMode == entry.key,
                      onSelected: (selected) {
                        if (!selected) return;
                        profile.themeMode = entry.key;
                        store.save();
                      },
                    ),
                ],
              ),
              const SizedBox(height: 24),
              PastelCard(
                child: Row(
                  children: [
                    Icon(Icons.style_outlined, color: p.action),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        'Ôn vừa sức, nhớ lâu hơn.',
                        style: Theme.of(context).textTheme.titleMedium,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              PastelButton(
                label: 'Xong',
                expand: true,
                onPressed: () => Navigator.pop(context),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
