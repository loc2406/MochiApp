import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../../core/database/mochi_store.dart';
import '../../core/theme/mochi_theme.dart';
import '../../core/theme/apple_glass_theme.dart';
import '../../shared/widgets/mochi_assets.dart';
import '../robot/robot_mascot_widget.dart';

class RobotShopScreen extends StatefulWidget {
  const RobotShopScreen({super.key});

  @override
  State<RobotShopScreen> createState() => _RobotShopScreenState();
}

class _RobotShopScreenState extends State<RobotShopScreen> {
  String _selectedCategory = 'all';

  @override
  Widget build(BuildContext context) {
    final store = context.watch<MochiStore>();
    final catalog = MochiStore.shopCatalog.where((item) {
      if (_selectedCategory == 'all') return true;
      return item.category == _selectedCategory;
    }).toList();

    return Scaffold(
      backgroundColor: AppleOS27Colors.systemBackground,
      appBar: AppBar(
        title: const Text('Robot Shop & Phụ kiện', style: TextStyle(fontWeight: FontWeight.w800)),
        actions: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            margin: const EdgeInsets.only(right: 16),
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.15),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: Colors.white.withValues(alpha: 0.25)),
            ),
            child: Row(
              children: [
                const Icon(Icons.star_rounded, color: AppleOS27Colors.cyberAmber, size: 18),
                const SizedBox(width: 5),
                Text(
                  '${store.stars}',
                  style: const TextStyle(fontWeight: FontWeight.w900, color: Color(0xFFFFF0B1), fontSize: 14),
                ),
              ],
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          // Apple OS27 Dark Liquid Showcase Fitting Room
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 16),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF1E293B), Color(0xFF0F172A)],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.15),
                  blurRadius: 16,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Column(
              children: [
                RobotMascotWidget(
                  size: 115,
                  emotion: store.robotEmotion,
                  primaryColor: Color(store.robotColorHex),
                  equippedAccessory: store.equippedAccessory,
                  equippedClothes: store.equippedClothes,
                  equippedSpecial: store.equippedSpecial,
                ),
                const SizedBox(height: 8),
                Text(
                  store.profile.robotName,
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 16),
                ),
                const SizedBox(height: 2),
                Text(
                  'Chuỗi hiện tại: ${store.currentStreak} ngày liên tục',
                  style: const TextStyle(color: Color(0xFFD6E3F7), fontSize: 12),
                ),
                const SizedBox(height: 10),
                // Color Picker Row with Apple Haptic
                Wrap(
                  spacing: 8,
                  children: MochiColors.robotPalettes.map((c) {
                    final isSelected = store.robotColorHex == c.toARGB32();
                    return GestureDetector(
                      onTap: () {
                        HapticFeedback.selectionClick();
                        store.changeRobotColor(c.toARGB32());
                      },
                      child: Container(
                        width: 24,
                        height: 24,
                        decoration: BoxDecoration(
                          color: c,
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: isSelected ? Colors.white : Colors.transparent,
                            width: 2.5,
                          ),
                        ),
                      ),
                    );
                  }).toList(),
                ),
              ],
            ),
          ),

          // Category Filters (Apple OS27 Segmented Chips)
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            color: Colors.white,
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  _buildCategoryChip('all', 'Tất cả'),
                  _buildCategoryChip('accessory', 'Phụ kiện'),
                  _buildCategoryChip('clothes', 'Trang phục'),
                  _buildCategoryChip('special', 'Đặc biệt'),
                ],
              ),
            ),
          ),

          // Catalog Grid - Responsive layoutBuilder with dynamic aspect ratio
          Expanded(
            child: LayoutBuilder(
              builder: (context, constraints) {
                // Adaptive aspect ratio prevents overflow on 360dp width screens
                final double itemRatio = constraints.maxWidth < 380 ? 0.72 : 0.78;

                return GridView.builder(
                  padding: const EdgeInsets.fromLTRB(16, 14, 16, 90), // Space for floating glass bar
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    crossAxisSpacing: 12,
                    mainAxisSpacing: 12,
                    childAspectRatio: itemRatio,
                  ),
                  itemCount: catalog.length,
                  itemBuilder: (context, index) {
                    final item = catalog[index];
                    final isOwned = store.ownedItems.contains(item.id);
                    final isEquipped = store.equippedAccessory == item.id ||
                        store.equippedClothes == item.id ||
                        store.equippedSpecial == item.id;
                    final canUnlock = store.currentStreak >= item.requiredStreak;

                    return FrostedGlassCard(
                      padding: const EdgeInsets.all(12),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          MochiShopAsset(itemId: item.assetId, size: 54),
                          const SizedBox(height: 6),
                          Text(
                            item.name,
                            textAlign: TextAlign.center,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13, color: AppleOS27Colors.textPrimary),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            item.desc,
                            textAlign: TextAlign.center,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontSize: 10.5, color: AppleOS27Colors.textSecondary, height: 1.25),
                          ),
                          const Spacer(),
                          if (!canUnlock)
                            Text(
                              'Cần chuỗi ${item.requiredStreak} ngày',
                              style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: AppleOS27Colors.sunsetCoral),
                            )
                          else if (!isOwned)
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                const Icon(Icons.star_rounded, color: AppleOS27Colors.cyberAmber, size: 14),
                                const SizedBox(width: 3),
                                Text('${item.price}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12, color: AppleOS27Colors.textPrimary)),
                              ],
                            ),
                          const SizedBox(height: 6),
                          SizedBox(
                            width: double.infinity,
                            child: isOwned
                                ? OutlinedButton(
                                    onPressed: () {
                                      HapticFeedback.selectionClick();
                                      store.equipItem(item.id, item.category);
                                    },
                                    style: OutlinedButton.styleFrom(
                                      foregroundColor: isEquipped ? AppleOS27Colors.sunsetCoral : AppleOS27Colors.electricViolet,
                                      side: BorderSide(color: isEquipped ? AppleOS27Colors.sunsetCoral : AppleOS27Colors.electricViolet, width: 1.2),
                                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                                      padding: const EdgeInsets.symmetric(vertical: 6),
                                    ),
                                    child: Text(
                                      isEquipped ? 'Tháo ra' : 'Mặc ngay',
                                      style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w800),
                                    ),
                                  )
                                : ElevatedButton(
                                    onPressed: (!canUnlock || store.stars < item.price)
                                        ? null
                                        : () {
                                            HapticFeedback.mediumImpact();
                                            final success = store.buyItem(item);
                                            if (success) {
                                              ScaffoldMessenger.of(context).showSnackBar(
                                                SnackBar(content: Text('Đã mở khóa ${item.name}!')),
                                              );
                                            }
                                          },
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: AppleOS27Colors.deepNavy,
                                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                                      padding: const EdgeInsets.symmetric(vertical: 6),
                                      elevation: 0,
                                    ),
                                    child: Text(
                                      item.price == 0 ? 'Nhận quà' : 'Mua',
                                      style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: Colors.white),
                                    ),
                                  ),
                          ),
                        ],
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCategoryChip(String cat, String label) {
    final isSelected = _selectedCategory == cat;
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: ChoiceChip(
        label: Text(label),
        selected: isSelected,
        selectedColor: AppleOS27Colors.electricViolet,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        labelStyle: TextStyle(
          color: isSelected ? Colors.white : AppleOS27Colors.textPrimary,
          fontWeight: FontWeight.w700,
          fontSize: 12,
        ),
        onSelected: (val) {
          if (val) {
            HapticFeedback.selectionClick();
            setState(() => _selectedCategory = cat);
          }
        },
      ),
    );
  }
}

