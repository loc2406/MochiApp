import '../../shared/widgets/floating_bar_inset.dart';
import '../../core/theme/mochi_theme.dart';
import '../rewards/robot_shop_screen.dart';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../../core/database/mochi_store.dart';
import '../../core/models/mochi_models.dart';
import '../../core/theme/apple_glass_theme.dart';
import '../../shared/widgets/mochi_icons.dart';
import '../robot/robot_mascot_widget.dart';
import '../focus/focus_timer_screen.dart';
import '../ai_tutor/ai_tutor_sheet.dart';

class TodayScreen extends StatelessWidget {
  final VoidCallback onNavigateToPlanner;
  final VoidCallback? onNavigateToAITutor;

  const TodayScreen({
    super.key,
    required this.onNavigateToPlanner,
    this.onNavigateToAITutor,
  });

  @override
  Widget build(BuildContext context) {
    final store = context.watch<MochiStore>();
    final pendingTasks = store.tasks.where((t) => !t.isDone).toList();
    final completedTasks = store.tasks.where((t) => t.isDone).toList();
    final total = store.tasks.length;
    final progressPct = total > 0 ? (completedTasks.length / total) : 0.0;

    return Scaffold(
      backgroundColor: AppleOS27Colors.systemBackground,
      appBar: AppBar(
        titleSpacing: 16,
        title: Row(
          children: [
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.15),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: Colors.white.withValues(alpha: 0.3),
                  width: 0.8,
                ),
              ),
              child: Center(
                child: MochiVectorIcon(
                  'robot',
                  size: 22,
                  color: Color(store.robotColorHex),
                ),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'Chào ${store.profile.name.isNotEmpty ? store.profile.name : "bạn"}!',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w800,
                      color: Colors.white,
                    ),
                  ),
                  Text(
                    'Học cùng ${store.profile.robotName}',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontSize: 11,
                      color: Color(0xFFD6E3F7),
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        actions: [
          // Clean Streak pill only
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            margin: const EdgeInsets.only(right: 16),
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.15),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: Colors.white.withValues(alpha: 0.25),
                width: 0.8,
              ),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(
                  Icons.local_fire_department_rounded,
                  color: AppleOS27Colors.sunsetCoral,
                  size: 17,
                ),
                const SizedBox(width: 5),
                Text(
                  '${store.currentStreak} ngày',
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w800,
                    fontSize: 13,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      body: RefreshIndicator(
        color: AppleOS27Colors.electricViolet,
        onRefresh: () async {
          await store.init();
        },
        child: LayoutBuilder(
          builder: (context, constraints) {
            final isWide = constraints.maxWidth >= 760;

            if (isWide) {
              // Bố cục Web Desktop Đa Cột
              return SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.symmetric(vertical: 8),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Cột Trái: Nhiệm vụ & Tiến độ (Flex 1.2)
                    Expanded(
                      flex: 12,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _buildProgressCard(
                            context,
                            completedTasks.length,
                            total,
                            progressPct,
                          ),
                          const SizedBox(height: 20),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text(
                                'Nhiệm vụ hôm nay',
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.w800,
                                  color: AppleOS27Colors.textPrimary,
                                  letterSpacing: -0.2,
                                ),
                              ),
                              TextButton.icon(
                                onPressed: () {
                                  HapticFeedback.selectionClick();
                                  onNavigateToPlanner();
                                },
                                icon: const Icon(
                                  Icons.add_circle_outline_rounded,
                                  size: 18,
                                  color: AppleOS27Colors.electricViolet,
                                ),
                                label: const Text(
                                  'Thêm việc',
                                  style: TextStyle(
                                    color: AppleOS27Colors.electricViolet,
                                    fontWeight: FontWeight.w700,
                                    fontSize: 13,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          if (pendingTasks.isEmpty && completedTasks.isEmpty)
                            _buildEmptyState(context)
                          else ...[
                            ...pendingTasks.map(
                              (task) => _buildTaskItem(context, store, task),
                            ),
                            if (completedTasks.isNotEmpty) ...[
                              const SizedBox(height: 16),
                              const Text(
                                'Đã hoàn thành',
                                style: TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w700,
                                  color: AppleOS27Colors.textSecondary,
                                ),
                              ),
                              const SizedBox(height: 6),
                              ...completedTasks.map(
                                (task) => _buildTaskItem(context, store, task),
                              ),
                            ],
                          ],
                        ],
                      ),
                    ),
                    const SizedBox(width: 28),
                    // Cột Phải: Mascot Buddy & AI Callout (Flex 9)
                    Expanded(
                      flex: 9,
                      child: Column(
                        children: [
                          _buildAppleHeroCard(context, store),
                          const SizedBox(height: 20),
                          _buildAITutorCallout(context, store),
                        ],
                      ),
                    ),
                  ],
                ),
              );
            }

            // Bố cục Mobile Dọc
            return ListView(
              physics: const AlwaysScrollableScrollPhysics(),
              padding: EdgeInsets.fromLTRB(16, 16, 16, FloatingBarInset.of(context) + 16),
              children: [
                _buildAppleHeroCard(context, store),
                const SizedBox(height: 16),
                _buildProgressCard(
                  context,
                  completedTasks.length,
                  total,
                  progressPct,
                ),
                const SizedBox(height: 20),
                Wrap(
                  alignment: WrapAlignment.spaceBetween,
                  crossAxisAlignment: WrapCrossAlignment.center,
                  children: [
                    const Text(
                      'Nhiệm vụ hôm nay',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w800,
                        color: AppleOS27Colors.textPrimary,
                        letterSpacing: -0.2,
                      ),
                    ),
                    TextButton.icon(
                      onPressed: () {
                        HapticFeedback.selectionClick();
                        onNavigateToPlanner();
                      },
                      icon: const Icon(
                        Icons.add_circle_outline_rounded,
                        size: 18,
                        color: AppleOS27Colors.electricViolet,
                      ),
                      label: const Text(
                        'Thêm việc',
                        style: TextStyle(
                          color: AppleOS27Colors.electricViolet,
                          fontWeight: FontWeight.w700,
                          fontSize: 13,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                if (pendingTasks.isEmpty && completedTasks.isEmpty)
                  _buildEmptyState(context)
                else ...[
                  ...pendingTasks.map(
                    (task) => _buildTaskItem(context, store, task),
                  ),
                  if (completedTasks.isNotEmpty) ...[
                    const SizedBox(height: 16),
                    const Text(
                      'Đã hoàn thành',
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        color: AppleOS27Colors.textSecondary,
                      ),
                    ),
                    const SizedBox(height: 6),
                    ...completedTasks.map(
                      (task) => _buildTaskItem(context, store, task),
                    ),
                  ],
                ],
                const SizedBox(height: 18),
                _buildAITutorCallout(context, store),
              ],
            );
          },
        ),
      ),
    );
  }

  // Apple OS27 Dark Liquid Hero Card
  Widget _buildAppleHeroCard(BuildContext context, MochiStore store) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF1E293B), Color(0xFF0F172A)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(
          color: Colors.white.withValues(alpha: 0.12),
          width: 1.0,
        ),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF0F172A).withValues(alpha: 0.25),
            blurRadius: 24,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: LayoutBuilder(
        builder: (context, constraints) {
          final mascotSize = constraints.maxWidth < 340 ? 88.0 : 102.0;

          return Row(
            children: [
              RobotMascotWidget(
                size: mascotSize,
                emotion: store.robotEmotion,
                primaryColor: Color(store.robotColorHex),
                equippedAccessory: store.equippedAccessory,
                equippedClothes: store.equippedClothes,
                equippedSpecial: store.equippedSpecial,
                onTap: () {
                  HapticFeedback.selectionClick();
                  store.setRobotEmotion(RobotEmotion.celebrate);
                },
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Flexible(
                          child: Text(
                            store.profile.robotName,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w900,
                              fontSize: 17,
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 8,
                            vertical: 3,
                          ),
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(
                              colors: [
                                AppleOS27Colors.electricViolet,
                                Color(0xFF9333EA),
                              ],
                            ),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Text(
                            'Lv.${(store.xp / 100).floor() + 1}',
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 10,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Text(
                      _getCompanionQuote(store),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: Color(0xFFD3E0F3),
                        fontSize: 12.5,
                        height: 1.35,
                      ),
                    ),
                    const SizedBox(height: 10),
                    Wrap(
                      spacing: 12,
                      runSpacing: 6,
                      children: [
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(
                              Icons.bolt_rounded,
                              color: AppleOS27Colors.cyberAmber,
                              size: 16,
                            ),
                            const SizedBox(width: 3),
                            Text(
                              '${store.xp} XP',
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 12,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ],
                        ),
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(
                              Icons.schedule_rounded,
                              color: AppleOS27Colors.oceanCyan,
                              size: 16,
                            ),
                            const SizedBox(width: 3),
                            Text(
                              '${store.totalStudyMinutes}p học',
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 12,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ],
                        ),
                        GestureDetector(
                          onTap: () {
                            HapticFeedback.selectionClick();
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (ctx) => const RobotShopScreen(),
                              ),
                            );
                          },
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8,
                              vertical: 2,
                            ),
                            decoration: BoxDecoration(
                              color: AppleOS27Colors.cyberAmber.withValues(
                                alpha: 0.2,
                              ),
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(
                                color: AppleOS27Colors.cyberAmber.withValues(
                                  alpha: 0.4,
                                ),
                                width: 0.8,
                              ),
                            ),
                            child: const Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(
                                  Icons.shopping_bag_outlined,
                                  color: AppleOS27Colors.cyberAmber,
                                  size: 13,
                                ),
                                SizedBox(width: 3),
                                Text(
                                  'Cửa hàng',
                                  style: TextStyle(
                                    color: AppleOS27Colors.cyberAmber,
                                    fontSize: 11,
                                    fontWeight: FontWeight.w800,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  String _getCompanionQuote(MochiStore store) {
    if (store.currentStreak >= 7) {
      return 'Chuỗi ${store.currentStreak} ngày học liên tục thật ấn tượng! Mochi rất tự hào về bạn!';
    }
    if (store.tasks.any((t) => !t.isDone)) {
      return 'Bắt đầu giải quyết nhiệm vụ đầu tiên hôm nay nhé!';
    }
    return 'Tuyệt vời! Bạn đã hoàn thành hết mục tiêu hôm nay. Hãy ôn lại Flashcard nhé!';
  }

  Widget _buildProgressCard(
    BuildContext context,
    int done,
    int total,
    double pct,
  ) {
    final pct100 = (pct * 100).toInt();
    return FrostedGlassCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Wrap(
            alignment: WrapAlignment.spaceBetween,
            spacing: 12,
            children: [
              const Text(
                'Tiến độ nhiệm vụ',
                style: TextStyle(
                  fontWeight: FontWeight.w700,
                  color: AppleOS27Colors.textPrimary,
                  fontSize: 14,
                ),
              ),
              Text(
                '$done / $total ($pct100%)',
                style: const TextStyle(
                  fontWeight: FontWeight.w800,
                  color: AppleOS27Colors.electricViolet,
                  fontSize: 13,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: LinearProgressIndicator(
              value: pct,
              minHeight: 8,
              backgroundColor: const Color(0xFFE2E8F0),
              valueColor: const AlwaysStoppedAnimation<Color>(
                AppleOS27Colors.neonEmerald,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTaskItem(
    BuildContext context,
    MochiStore store,
    TaskModel task,
  ) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      child: Material(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        child: InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: () {
            HapticFeedback.lightImpact();
            store.toggleTask(task.id, !task.isDone);
          },
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(18),
              border: Border.all(
                color: task.isDone ? Colors.transparent : const Color(0xFFE2E8F0),
                width: 1.0,
              ),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFF0F172A).withValues(alpha: 0.03),
                  blurRadius: 10,
                  offset: const Offset(0, 3),
                ),
              ],
            ),
            child: Row(
              children: [
                Checkbox(
                  value: task.isDone,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(6),
                  ),
                  activeColor: AppleOS27Colors.neonEmerald,
                  onChanged: (val) {
                    HapticFeedback.lightImpact();
                    store.toggleTask(task.id, val ?? false);
                  },
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        task.title,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: 14.5,
                          fontWeight: FontWeight.w700,
                          color: task.isDone
                              ? AppleOS27Colors.textTertiary
                              : AppleOS27Colors.textPrimary,
                          decoration: task.isDone ? TextDecoration.lineThrough : null,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Wrap(
                        crossAxisAlignment: WrapCrossAlignment.center,
                        runSpacing: 4,
                        children: [
                          if (task.scheduledTime != null && task.scheduledTime!.isNotEmpty) ...[
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 6,
                                vertical: 2,
                              ),
                              margin: const EdgeInsets.only(right: 6),
                              decoration: BoxDecoration(
                                color: MochiColors.purple.withValues(alpha: 0.12),
                                borderRadius: BorderRadius.circular(6),
                              ),
                              child: Text(
                                task.scheduledTime!,
                                style: const TextStyle(
                                  fontSize: 11,
                                  fontWeight: FontWeight.w800,
                                  color: MochiColors.purple,
                                ),
                              ),
                            ),
                          ],
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 6,
                              vertical: 2,
                            ),
                            decoration: BoxDecoration(
                              color: AppleOS27Colors.cupertinoBlue.withValues(
                                alpha: 0.1,
                              ),
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: Text(
                              task.subject,
                              style: const TextStyle(
                                fontSize: 11,
                                fontWeight: FontWeight.w700,
                                color: AppleOS27Colors.cupertinoBlue,
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Text(
                            '${task.durationMinutes} phút',
                            style: const TextStyle(
                              fontSize: 12,
                              color: AppleOS27Colors.textSecondary,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                if (!task.isDone)
                  Padding(
                    padding: const EdgeInsets.only(left: 8),
                    child: ElevatedButton(
                      onPressed: () {
                        HapticFeedback.selectionClick();
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (ctx) => FocusTimerScreen(targetTask: task),
                          ),
                        );
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppleOS27Colors.deepNavy,
                        padding: const EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 8,
                        ),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        elevation: 0,
                      ),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            Icons.play_arrow_rounded,
                            size: 16,
                            color: Colors.white,
                          ),
                          SizedBox(width: 3),
                          Text(
                            'Học ngay',
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildEmptyState(BuildContext context) {
    return FrostedGlassCard(
      padding: const EdgeInsets.all(28),
      child: Column(
        children: [
          const Icon(
            Icons.checklist_rtl_rounded,
            size: 48,
            color: AppleOS27Colors.electricViolet,
          ),
          const SizedBox(height: 12),
          const Text(
            'Chưa có bài tập nào hôm nay',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w700,
              color: AppleOS27Colors.textPrimary,
            ),
          ),
          const SizedBox(height: 6),
          const Text(
            'Hãy thêm bài tập mới hoặc để Mochi AI chia nhỏ mục tiêu của bạn!',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 13,
              color: AppleOS27Colors.textSecondary,
            ),
          ),
          const SizedBox(height: 16),
          ElevatedButton.icon(
            onPressed: () {
              HapticFeedback.selectionClick();
              onNavigateToPlanner();
            },
            icon: const Icon(Icons.add, size: 18),
            label: const Text('Thêm nhiệm vụ mới'),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppleOS27Colors.deepNavy,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAITutorCallout(BuildContext context, MochiStore store) {
    return FrostedGlassCard(
      backgroundColor: AppleOS27Colors.electricViolet.withValues(alpha: 0.08),
      borderColor: AppleOS27Colors.electricViolet.withValues(alpha: 0.3),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(14),
              boxShadow: [
                BoxShadow(
                  color: AppleOS27Colors.electricViolet.withValues(alpha: 0.15),
                  blurRadius: 10,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: const MochiVectorIcon(
              'chat',
              size: 24,
              color: AppleOS27Colors.electricViolet,
            ),
          ),
          const SizedBox(width: 12),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Gặp bài tập khó?',
                  style: TextStyle(
                    fontWeight: FontWeight.w800,
                    fontSize: 14.5,
                    color: AppleOS27Colors.textPrimary,
                  ),
                ),
                SizedBox(height: 2),
                Text(
                  'Hỏi Mochi AI để được hướng dẫn phương pháp giải từng bước!',
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 11.5,
                    color: AppleOS27Colors.textSecondary,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          ElevatedButton(
            onPressed: () {
              HapticFeedback.selectionClick();
              if (onNavigateToAITutor != null) {
                onNavigateToAITutor!();
              } else {
                showModalBottomSheet(
                  context: context,
                  isScrollControlled: true,
                  backgroundColor: Colors.transparent,
                  builder: (ctx) => const AITutorSheet(),
                );
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppleOS27Colors.electricViolet,
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
              ),
              elevation: 0,
            ),
            child: const Text(
              'Hỏi AI',
              style: TextStyle(fontWeight: FontWeight.w800, fontSize: 13),
            ),
          ),
        ],
      ),
    );
  }
}
