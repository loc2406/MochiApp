import '../../shared/widgets/note_button.dart';
import '../../shared/widgets/floating_bar_inset.dart';
import '../learning/learning_hub_screen.dart';
import '../../core/services/notification_service.dart';
import '../rewards/robot_shop_screen.dart';
import '../auth/auth_screen.dart';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/database/mochi_store.dart';
import '../../core/theme/mochi_theme.dart';
import '../settings/settings_screen.dart';

class ProfileCalendarScreen extends StatefulWidget {
  const ProfileCalendarScreen({super.key});

  @override
  State<ProfileCalendarScreen> createState() => _ProfileCalendarScreenState();
}

class _ProfileCalendarScreenState extends State<ProfileCalendarScreen> {
  DateTime _currentMonth = DateTime(
    DateTime.now().year,
    DateTime.now().month,
    1,
  );

  @override
  Widget build(BuildContext context) {
    final store = context.watch<MochiStore>();

    return Scaffold(
      backgroundColor: MochiColors.background,
      appBar: AppBar(
        title: const Text(
          'Hành trình & Lịch học',
          style: TextStyle(fontWeight: FontWeight.w800),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.storefront_rounded, color: Colors.white),
            tooltip: 'Cửa hàng phụ kiện Robot',
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (ctx) => const RobotShopScreen()),
              );
            },
          ),
          IconButton(
            icon: const Icon(Icons.settings_outlined),
            tooltip: 'Cài đặt',
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (ctx) => const SettingsScreen()),
              );
            },
          ),
        ],
      ),
      body: ListView(
        padding: EdgeInsets.fromLTRB(16, 16, 16, FloatingBarInset.of(context) + 16),
        children: [
          // Learner Profile Overview Card
          _buildProfileCard(context, store),
          if (store.syncError != null)
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Text(
                  store.syncError!,
                  style: const TextStyle(color: MochiColors.danger),
                ),
              ),
            ),
          const SizedBox(height: 16),

          Card(
            child: ListTile(
              leading: const Icon(Icons.school_outlined),
              title: const Text('Hồ sơ học tập và lịch chung', style: TextStyle(fontWeight: FontWeight.w700)),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  NoteButton(note: 'Quản lý tiến độ từng môn học, bài tập cần làm và thời khóa biểu lên lớp hàng tuần.'),
                  const Icon(Icons.chevron_right),
                ],
              ),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const LearningHubScreen()),
              ),
            ),
          ),
          const SizedBox(height: 16),




          // Monthly Activity Attendance Calendar
          _buildCalendarCard(context, store),
          const SizedBox(height: 16),

          // Recent Study Sessions History
          _buildSessionHistory(context, store),
        ],
      ),
    );
  }

  Widget _buildProfileCard(BuildContext context, MochiStore store) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  radius: 28,
                  backgroundColor: MochiColors.lavender,
                  child: Text(
                    store.profile.name.isNotEmpty
                        ? store.profile.name[0].toUpperCase()
                        : 'M',
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w800,
                      color: MochiColors.purple,
                    ),
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        store.profile.name.isNotEmpty
                            ? store.profile.name
                            : 'Người học Mochi',
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w800,
                          color: MochiColors.navy,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        '${store.profile.gradeBand} · Đồng hành: ${store.profile.robotName}',
                        style: const TextStyle(
                          fontSize: 12,
                          color: MochiColors.muted,
                        ),
                      ),
                      const SizedBox(height: 6),
                      if (store.cloudService.hasActiveUser)
                        Row(
                          children: [
                            Icon(
                              store.isCloudSynced
                                  ? Icons.cloud_done_rounded
                                  : Icons.sync_problem_rounded,
                              size: 14,
                              color: store.isCloudSynced
                                  ? MochiColors.green
                                  : MochiColors.muted,
                            ),
                            const SizedBox(width: 4),
                            Expanded(
                              child: Text(
                                store.cloudService.userEmail ?? 'Đã đồng bộ',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                  fontSize: 11.5,
                                  color: MochiColors.green,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ),
                            TextButton(
                              style: TextButton.styleFrom(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 8,
                                  vertical: 2,
                                ),
                                minimumSize: Size.zero,
                                tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                              ),
                              onPressed: () async {
                                await store.cloudService.signOut();
                                store.refreshCloudAuth();
                              },
                              child: const Text(
                                'Đăng xuất',
                                style: TextStyle(
                                  fontSize: 11,
                                  color: MochiColors.danger,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ),
                          ],
                        )
                      else
                        OutlinedButton.icon(
                          style: OutlinedButton.styleFrom(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 10,
                              vertical: 4,
                            ),
                            minimumSize: Size.zero,
                            tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                            side: const BorderSide(
                              color: MochiColors.purple,
                              width: 0.8,
                            ),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8),
                            ),
                          ),
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (ctx) => AuthScreen(
                                  isSkippable: true,
                                  onAuthenticated: () {
                                    Navigator.pop(ctx);
                                  },
                                ),
                              ),
                            );
                          },
                          icon: const Icon(
                            Icons.cloud_sync_rounded,
                            size: 14,
                            color: MochiColors.purple,
                          ),
                          label: const Text(
                            'Đăng nhập đồng bộ',
                            style: TextStyle(
                              fontSize: 11.5,
                              color: MochiColors.purple,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
              ],
            ),
            const Divider(height: 24),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildStatPill(
                  'Chuỗi kỷ lục',
                  '${store.longestStreak} ngày',
                  Icons.local_fire_department,
                  MochiColors.orange,
                ),
                InkWell(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (ctx) => const RobotShopScreen(),
                      ),
                    );
                  },
                  borderRadius: BorderRadius.circular(10),
                  child: _buildStatPill(
                    'Cửa hàng sao',
                    '${store.stars} sao',
                    Icons.storefront,
                    MochiColors.starGold,
                  ),
                ),
                _buildStatPill(
                  'Tổng thời gian',
                  '${store.totalStudyMinutes} phút',
                  Icons.timer,
                  MochiColors.cyan,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatPill(String title, String val, IconData icon, Color color) {
    return Column(
      children: [
        Icon(icon, color: color, size: 22),
        const SizedBox(height: 4),
        Text(
          val,
          style: const TextStyle(
            fontWeight: FontWeight.w800,
            fontSize: 14,
            color: MochiColors.navy,
          ),
        ),
        Text(
          title,
          style: const TextStyle(fontSize: 11, color: MochiColors.muted),
        ),
      ],
    );
  }

  Widget _buildCalendarCard(BuildContext context, MochiStore store) {
    final year = _currentMonth.year;
    final month = _currentMonth.month;
    final daysInMonth = DateTime(year, month + 1, 0).day;
    final firstWeekday = DateTime(year, month, 1).weekday; // 1=Mon, 7=Sun

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Tháng $month/$year',
                  style: const TextStyle(
                    fontWeight: FontWeight.w800,
                    fontSize: 16,
                    color: MochiColors.navy,
                  ),
                ),
                Row(
                  children: [
                    IconButton(
                      icon: const Icon(Icons.chevron_left),
                      onPressed: () {
                        setState(() {
                          _currentMonth = DateTime(year, month - 1, 1);
                        });
                      },
                    ),
                    IconButton(
                      icon: const Icon(Icons.chevron_right),
                      onPressed: () {
                        setState(() {
                          _currentMonth = DateTime(year, month + 1, 1);
                        });
                      },
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 10),
            // Weekday Header
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: ['T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'CN']
                  .map(
                    (d) => Text(
                      d,
                      style: const TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 12,
                        color: MochiColors.muted,
                      ),
                    ),
                  )
                  .toList(),
            ),
            const SizedBox(height: 10),
            // Days Grid
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 7,
                mainAxisSpacing: 6,
                crossAxisSpacing: 6,
              ),
              itemCount: (firstWeekday - 1) + daysInMonth,
              itemBuilder: (context, index) {
                if (index < firstWeekday - 1) {
                  return const SizedBox.shrink();
                }
                final day = index - (firstWeekday - 1) + 1;
                final dateStr =
                    '$year-${month.toString().padLeft(2, '0')}-${day.toString().padLeft(2, '0')}';
                final hasActivity = store.activityDays[dateStr] ?? false;
                // Kiểm tra xem ngày này có lịch học được lên trước không
                final hasScheduledPlan = store.tasks.any(
                  (t) => t.scheduledDate == dateStr,
                );
                final isToday =
                    (year == DateTime.now().year &&
                    month == DateTime.now().month &&
                    day == DateTime.now().day);

                // Màu sắc: Có lịch học -> Tím Mochi; Đã hoàn thành học -> Xanh Emerald; Chưa có gì -> Trong suốt
                final Color cellBg = hasScheduledPlan
                    ? MochiColors.purple.withValues(alpha: 0.15)
                    : (hasActivity ? MochiColors.green : Colors.transparent);
                final Color cellBorder = hasScheduledPlan
                    ? MochiColors.purple
                    : (hasActivity
                          ? MochiColors.green
                          : (isToday
                                ? MochiColors.orange
                                : MochiColors.border));

                return InkWell(
                  onTap: () => _showDayScheduleDialog(
                    context,
                    store,
                    dateStr,
                    day,
                    month,
                    year,
                    hasActivity,
                  ),
                  borderRadius: BorderRadius.circular(20),
                  child: Container(
                    decoration: BoxDecoration(
                      color: cellBg,
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: cellBorder,
                        width: (hasScheduledPlan || hasActivity || isToday)
                            ? 1.5
                            : 0.8,
                      ),
                    ),
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        Text(
                          '$day',
                          style: TextStyle(
                            fontSize: 11.5,
                            fontWeight: FontWeight.w800,
                            color: hasActivity && !hasScheduledPlan
                                ? Colors.white
                                : (hasScheduledPlan
                                      ? MochiColors.purple
                                      : MochiColors.ink),
                          ),
                        ),
                        // Ngọn lửa Streak hiển thị mức độ từ nhỏ đến lớn dần theo chuỗi đạt được
                        if (hasActivity)
                          Positioned(
                            bottom: 1,
                            child: _buildStreakFlameIcon(
                              store.streakOn(DateTime(year, month, day)),
                            ),
                          ),
                      ],
                    ),
                  ),
                );
              },
            ),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 8,
                  height: 8,
                  decoration: const BoxDecoration(
                    color: MochiColors.purple,
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 4),
                const Text(
                  'Có lịch học',
                  style: TextStyle(
                    fontSize: 10.5,
                    fontWeight: FontWeight.w700,
                    color: MochiColors.purple,
                  ),
                ),
                const SizedBox(width: 12),
                Container(
                  width: 8,
                  height: 8,
                  decoration: const BoxDecoration(
                    color: MochiColors.green,
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 4),
                const Text(
                  'Đã hoàn thành',
                  style: TextStyle(
                    fontSize: 10.5,
                    fontWeight: FontWeight.w700,
                    color: MochiColors.green,
                  ),
                ),
                const SizedBox(width: 12),
                const Icon(
                  Icons.local_fire_department_rounded,
                  size: 12,
                  color: Colors.orange,
                ),
                const SizedBox(width: 2),
                const Text(
                  'Cấp độ lửa Streak',
                  style: TextStyle(
                    fontSize: 10.5,
                    fontWeight: FontWeight.w700,
                    color: Colors.orange,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSessionHistory(BuildContext context, MochiStore store) {
    if (store.sessions.isEmpty) {
      return const SizedBox.shrink();
    }

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Nhật ký các phiên học gần đây',
              style: TextStyle(
                fontWeight: FontWeight.w800,
                fontSize: 16,
                color: MochiColors.navy,
              ),
            ),
            const SizedBox(height: 12),
            ...store.sessions.take(5).map((s) {
              return Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: MochiColors.lavender,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: const Icon(
                        Icons.timer_outlined,
                        color: MochiColors.purple,
                        size: 20,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            s.taskTitle,
                            style: const TextStyle(
                              fontWeight: FontWeight.w700,
                              fontSize: 14,
                            ),
                          ),
                          Text(
                            '${s.startedAt.day}/${s.startedAt.month} · ${(s.activeSeconds / 60).round()} phút · Đánh giá: ${s.selfRating}/5',
                            style: const TextStyle(
                              fontSize: 11,
                              color: MochiColors.muted,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(
                          Icons.star_rounded,
                          size: 16,
                          color: MochiColors.starGold,
                        ),
                        const SizedBox(width: 2),
                        Text(
                          '+${s.earnedStars}',
                          style: const TextStyle(
                            fontWeight: FontWeight.w800,
                            color: MochiColors.starGold,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              );
            }),
          ],
        ),
      ),
    );
  }

  void _showDayScheduleDialog(
    BuildContext context,
    MochiStore store,
    String dateStr,
    int day,
    int month,
    int year,
    bool hasActivity,
  ) {
    final dayTasks = store.tasks.where((t) {
      if (t.scheduledDate != null && t.scheduledDate == dateStr) return true;
      final createdStr =
          '${t.createdAt.year}-${t.createdAt.month.toString().padLeft(2, '0')}-${t.createdAt.day.toString().padLeft(2, '0')}';
      return createdStr == dateStr;
    }).toList();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => Container(
        constraints: BoxConstraints(
          maxHeight: MediaQuery.of(context).size.height * 0.7,
        ),
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: MochiColors.border,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Lịch học ngày $day/$month/$year',
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w800,
                        color: MochiColors.navy,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      hasActivity
                          ? 'Ngày này đã có hoạt động học tập'
                          : 'Chưa có hoạt động nào hoàn thành',
                      style: const TextStyle(
                        fontSize: 12,
                        color: MochiColors.muted,
                      ),
                    ),
                  ],
                ),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 4,
                  ),
                  decoration: BoxDecoration(
                    color: hasActivity
                        ? MochiColors.green.withValues(alpha: 0.15)
                        : Colors.grey.shade100,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    hasActivity ? 'Đã học' : 'Chưa học',
                    style: TextStyle(
                      color: hasActivity ? MochiColors.green : Colors.grey,
                      fontWeight: FontWeight.w800,
                      fontSize: 11,
                    ),
                  ),
                ),
              ],
            ),
            const Divider(height: 24),
            if (dayTasks.isEmpty)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 24),
                child: Center(
                  child: Text(
                    'Không có nhiệm vụ nào được lên lịch cho ngày này.',
                    style: TextStyle(color: MochiColors.muted, fontSize: 13),
                  ),
                ),
              )
            else
              Expanded(
                child: ListView.builder(
                  shrinkWrap: true,
                  itemCount: dayTasks.length,
                  itemBuilder: (ctx, i) {
                    final t = dayTasks[i];
                    final timeLabel = t.scheduledTime ?? 'Buổi tối';
                    return Container(
                      margin: const EdgeInsets.only(bottom: 10),
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: MochiColors.background,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: MochiColors.border),
                      ),
                      child: Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8,
                              vertical: 4,
                            ),
                            decoration: BoxDecoration(
                              color: MochiColors.purple.withValues(alpha: 0.1),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                const Icon(
                                  Icons.access_time_rounded,
                                  size: 12,
                                  color: MochiColors.purple,
                                ),
                                const SizedBox(width: 4),
                                Text(
                                  timeLabel,
                                  style: const TextStyle(
                                    color: MochiColors.purple,
                                    fontWeight: FontWeight.w800,
                                    fontSize: 11,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  t.title,
                                  style: TextStyle(
                                    fontWeight: FontWeight.w700,
                                    fontSize: 13.5,
                                    decoration: t.isDone
                                        ? TextDecoration.lineThrough
                                        : null,
                                  ),
                                ),
                                Text(
                                  '${t.subject} · ${t.durationMinutes} phút',
                                  style: const TextStyle(
                                    fontSize: 11,
                                    color: MochiColors.muted,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          IconButton(
                            icon: const Icon(
                              Icons.alarm_add_rounded,
                              color: MochiColors.orange,
                              size: 20,
                            ),
                            tooltip: 'Đặt chuông báo giờ học',
                            onPressed: () async {
                              final parts = timeLabel.split(':');
                              final hour = parts.isNotEmpty
                                  ? int.tryParse(parts[0]) ?? 20
                                  : 20;
                              final minute = parts.length > 1
                                  ? int.tryParse(parts[1]) ?? 0
                                  : 0;
                              final reminderDate = DateTime(
                                year,
                                month,
                                day,
                                hour,
                                minute,
                              );
                              if (reminderDate.isAfter(DateTime.now())) {
                                await NotificationService().scheduleLiveReview(
                                  t.id,
                                  'Đến giờ học: ${t.title} (${t.durationMinutes} phút)',
                                );
                                if (context.mounted) {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(
                                      content: Text(
                                        'Đã đặt nhắc nhở lúc $timeLabel ngày $day/$month!',
                                      ),
                                    ),
                                  );
                                }
                              } else {
                                if (context.mounted) {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(
                                      content: Text(
                                        'Giờ đã qua, hãy chọn ngày trong tương lai.',
                                      ),
                                    ),
                                  );
                                }
                              }
                            },
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildStreakFlameIcon(int streak) {
    // Kích thước và màu lửa tăng dần theo độ dài chuỗi ngày liên tục
    double size = 8.0;
    Color flameColor = Colors.orange.shade300;
    if (streak >= 14) {
      size = 14.0;
      flameColor = Colors.amberAccent.shade400;
    } else if (streak >= 7) {
      size = 12.0;
      flameColor = Colors.deepOrangeAccent;
    } else if (streak >= 3) {
      size = 10.0;
      flameColor = Colors.orange;
    }
    return Icon(
      Icons.local_fire_department_rounded,
      size: size,
      color: flameColor,
    );
  }


}
