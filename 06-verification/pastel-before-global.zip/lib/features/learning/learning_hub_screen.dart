import 'dart:convert';
import 'package:image_picker/image_picker.dart';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/database/mochi_store.dart';
import '../../core/models/mochi_models.dart';
import '../../core/learning/learning_models.dart';
import '../../core/learning/curriculum_catalog.dart';
import '../../core/theme/mochi_theme.dart';
import '../focus/focus_timer_screen.dart';

class LearningHubScreen extends StatefulWidget {
  final int initialTab;
  const LearningHubScreen({super.key, this.initialTab = 0});
  @override
  State<LearningHubScreen> createState() => _LearningHubScreenState();
}

class _LearningHubScreenState extends State<LearningHubScreen> {
  void _error(Object e) {
    if (mounted)
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.toString().replaceFirst('Bad state: ', ''))),
      );
  }

  Future<void> _setup(MochiStore store) async {
    var grade = store.learning.gradeLevel ?? 11;
    final year = TextEditingController(text: store.learning.academicYear);
    final selected = store.learning.courses.map((x) => x.subject).toSet();
    if (selected.isEmpty) selected.add('Toán');
    await showDialog<void>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialog) => AlertDialog(
          title: const Text('Lớp và môn đang học'),
          content: SizedBox(
            width: 560,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  DropdownButtonFormField<int>(
                    initialValue: grade,
                    decoration: const InputDecoration(labelText: 'Lớp'),
                    items: [
                      for (var i = 1; i <= 12; i++)
                        DropdownMenuItem(value: i, child: Text('Lớp $i')),
                    ],
                    onChanged: (v) => setDialog(() => grade = v!),
                  ),
                  TextField(
                    controller: year,
                    decoration: const InputDecoration(
                      labelText: 'Năm học',
                      hintText: 'Ví dụ: 2026–2027',
                    ),
                  ),
                  const SizedBox(height: 16),
                  const Text('Chỉ chọn môn bạn thực sự học. Có thể đổi sau.'),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    children: learningSubjectChoices
                        .map(
                          (subject) => FilterChip(
                            label: Text(subject),
                            selected: selected.contains(subject),
                            onSelected: (on) => setDialog(() {
                              on
                                  ? selected.add(subject)
                                  : selected.remove(subject);
                            }),
                          ),
                        )
                        .toList(),
                  ),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Hủy'),
            ),
            FilledButton(
              onPressed: () async {
                if (year.text.trim().isEmpty || selected.isEmpty) {
                  _error('Chọn môn và nhập năm học.');
                  return;
                }
                try {
                  final courses = selected.map((s) {
                    final old = store.learning.courses
                        .where((x) => x.subject == s)
                        .firstOrNull;
                    return grade == store.learning.gradeLevel && old != null
                        ? old
                        : CurriculumCatalog.courseFor(s, grade);
                  }).toList();
                  await store.saveLearningSetup(
                    gradeLevel: grade,
                    academicYear: year.text,
                    courses: courses,
                  );
                  if (ctx.mounted) Navigator.pop(ctx);
                } catch (e) {
                  _error(e);
                }
              },
              child: const Text('Lưu hồ sơ'),
            ),
          ],
        ),
      ),
    );
    await Future<void>.delayed(const Duration(milliseconds: 300));
    year.dispose();
  }

  Future<void> _editCourse(MochiStore store, LearningCourse course) async {
    final book = TextEditingController(text: course.textbook),
        topics = TextEditingController();
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(course.subject),
        content: SizedBox(
          width: 540,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: book,
                  decoration: const InputDecoration(
                    labelText: 'Bộ sách / tài liệu đang theo học (tùy chọn)',
                  ),
                ),
                TextField(
                  controller: topics,
                  maxLines: 5,
                  decoration: const InputDecoration(
                    labelText: 'Thêm chủ đề theo lớp, mỗi dòng một chủ đề',
                    helperText:
                        'Nội dung bạn nhập; không gắn nhãn nguồn đã xác minh.',
                  ),
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Hủy'),
          ),
          FilledButton(
            onPressed: () async {
              final added = topics.text
                  .split('\n')
                  .map((x) => x.trim())
                  .where((x) => x.isNotEmpty)
                  .toSet();
              final updated = LearningCourse(
                id: course.id,
                subject: course.subject,
                textbook: book.text.trim(),
                sourceLabel: course.sourceLabel,
                topics: [
                  ...course.topics,
                  for (final title in added)
                    if (!course.topics.any((x) => x.title == title))
                      LearningTopic(
                        id: '${course.id}/user/${DateTime.now().microsecondsSinceEpoch}/${Uri.encodeComponent(title)}',
                        title: title,
                        sourceRef: 'user-provided',
                      ),
                ],
              );
              store.learning.courses = store.learning.courses
                  .map((x) => x.id == course.id ? updated : x)
                  .toList();
              await store.save();
              if (ctx.mounted) Navigator.pop(ctx);
            },
            child: const Text('Lưu'),
          ),
        ],
      ),
    );
    await Future<void>.delayed(const Duration(milliseconds: 300));
    book.dispose();
    topics.dispose();
  }

  Future<void> _assignment(MochiStore store) async {
    final title = TextEditingController(),
        minutes = TextEditingController(text: '25');
    var subject = store.learning.courses.firstOrNull?.subject ?? 'Toán',
        kind = 'homework';
    DateTime? due;
    final linked = <String>{}, topicIds = <String>{};
    String? error;
    await showDialog<void>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialog) => AlertDialog(
          title: const Text('Bài tập và việc cần học'),
          content: SizedBox(
            width: 560,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  TextField(
                    controller: title,
                    decoration: const InputDecoration(
                      labelText: 'Việc cụ thể',
                      hintText: 'Làm bài 1–5 thầy giao',
                    ),
                  ),
                  const SizedBox(height: 12),
                  DropdownButtonFormField<String>(
                    initialValue: subject,
                    isExpanded: true,
                    decoration: const InputDecoration(labelText: 'Môn'),
                    items:
                        {
                              ...learningSubjectChoices,
                              ...store.learning.courses.map((x) => x.subject),
                            }
                            .map(
                              (s) => DropdownMenuItem(value: s, child: Text(s)),
                            )
                            .toList(),
                    onChanged: (v) => setDialog(() {
                      subject = v!;
                      topicIds.clear();
                    }),
                  ),
                  DropdownButtonFormField<String>(
                    initialValue: kind,
                    isExpanded: true,
                    decoration: const InputDecoration(labelText: 'Loại việc'),
                    items: const [
                      DropdownMenuItem(
                        value: 'homework',
                        child: Text('Bài được giao'),
                      ),
                      DropdownMenuItem(
                        value: 'preparation',
                        child: Text('Chuẩn bị bài trên lớp'),
                      ),
                      DropdownMenuItem(
                        value: 'learn',
                        child: Text('Học phần mới'),
                      ),
                      DropdownMenuItem(
                        value: 'review',
                        child: Text('Ôn lại phần cần luyện'),
                      ),
                      DropdownMenuItem(
                        value: 'practice',
                        child: Text('Luyện mục tiêu'),
                      ),
                      DropdownMenuItem(value: 'mock', child: Text('Luyện đề')),
                    ],
                    onChanged: (v) => setDialog(() => kind = v!),
                  ),
                  TextField(
                    controller: minutes,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                      labelText: 'Tổng thời lượng dự kiến (phút)',
                      helperText: 'Việc dài được chia thành các phiên; không tự đánh dấu cả bài xong sau một phiên.',
                    ),
                  ),
                  TextButton.icon(
                    icon: const Icon(Icons.event_outlined),
                    label: Text(
                      due == null
                          ? 'Chọn hạn nộp / cần xong (nếu có)'
                          : 'Hạn: ${due!.day}/${due!.month} ${learningClock(due!.hour * 60 + due!.minute)}',
                    ),
                    onPressed: () async {
                      final date = await showDatePicker(
                        context: ctx,
                        initialDate: DateTime.now(),
                        firstDate: DateTime.now().subtract(
                          const Duration(days: 365),
                        ),
                        lastDate: DateTime.now().add(const Duration(days: 730)),
                      );
                      if (date == null || !ctx.mounted) return;
                      final time = await showTimePicker(
                        context: ctx,
                        initialTime: TimeOfDay.now(),
                      );
                      if (time != null)
                        setDialog(
                          () => due = DateTime(
                            date.year,
                            date.month,
                            date.day,
                            time.hour,
                            time.minute,
                          ),
                        );
                    },
                  ),
                  if (store.goals.isNotEmpty) ...[
                    const Text(
                      'Có thể phục vụ nhiều mục tiêu, không nhân đôi công việc:',
                    ),
                    ...store.goals
                        .where((g) => !g.isDone)
                        .map(
                          (g) => CheckboxListTile(
                            dense: true,
                            contentPadding: EdgeInsets.zero,
                            title: Text(g.title),
                            value: linked.contains(g.id),
                            onChanged: (v) => setDialog(() {
                              v == true
                                  ? linked.add(g.id)
                                  : linked.remove(g.id);
                            }),
                          ),
                        ),
                  ],
                  if ((store.learning.courses
                              .where((x) => x.subject == subject)
                              .firstOrNull
                              ?.topics ??
                          [])
                      .isNotEmpty)
                    ExpansionTile(
                      tilePadding: EdgeInsets.zero,
                      title: const Text('Liên kết chủ đề (tùy chọn)'),
                      children: [
                        for (final t
                            in store.learning.courses
                                .firstWhere((x) => x.subject == subject)
                                .topics)
                          CheckboxListTile(
                            dense: true,
                            title: Text(t.title),
                            value: topicIds.contains(t.id),
                            onChanged: (v) => setDialog(() {
                              v == true
                                  ? topicIds.add(t.id)
                                  : topicIds.remove(t.id);
                            }),
                          ),
                      ],
                    ),
                  if (error != null)
                    Text(error!, style: const TextStyle(color: Colors.red)),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Hủy'),
            ),
            FilledButton(
              onPressed: () {
                final n = int.tryParse(minutes.text.trim());
                if (title.text.trim().isEmpty ||
                    n == null ||
                    n < 1 ||
                    n > 1440) {
                  setDialog(
                    () => error =
                        'Nhập tên việc và thời lượng từ 1 đến 1440 phút.',
                  );
                  return;
                }
                store.addTask(
                  title: title.text.trim(),
                  subject: subject,
                  duration: n,
                  kind: kind,
                  dueAt: due,
                  goalIds: linked.toList(),
                  topicIds: topicIds.toList(),
                );
                Navigator.pop(ctx);
              },
              child: const Text('Thêm việc'),
            ),
          ],
        ),
      ),
    );
    await Future<void>.delayed(const Duration(milliseconds: 300));
    title.dispose();
    minutes.dispose();
  }

  Future<void> _lesson(MochiStore store) async {
    var weekday = DateTime.now().weekday,
        subject = store.learning.courses.firstOrNull?.subject ?? 'Toán';
    TimeOfDay? start, end;
    String? error;
    await showDialog<void>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialog) => AlertDialog(
          title: const Text('Thêm giờ lên lớp / học thêm'),
          content: SizedBox(
            width: 500,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  DropdownButtonFormField<String>(
                    initialValue: subject,
                    isExpanded: true,
                    decoration: const InputDecoration(labelText: 'Môn'),
                    items:
                        {
                              ...learningSubjectChoices,
                              ...store.learning.courses.map((x) => x.subject),
                            }
                            .map(
                              (s) => DropdownMenuItem(value: s, child: Text(s)),
                            )
                            .toList(),
                    onChanged: (v) => setDialog(() => subject = v!),
                  ),
                  DropdownButtonFormField<int>(
                    initialValue: weekday,
                    decoration: const InputDecoration(
                      labelText: 'Lặp lại hàng tuần',
                    ),
                    items: [
                      for (var d = 1; d <= 7; d++)
                        DropdownMenuItem(
                          value: d,
                          child: Text(d == 7 ? 'Chủ nhật' : 'Thứ ${d + 1}'),
                        ),
                    ],
                    onChanged: (v) => setDialog(() => weekday = v!),
                  ),
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      OutlinedButton(
                        onPressed: () async {
                          final t = await showTimePicker(
                            context: ctx,
                            initialTime: start ?? TimeOfDay.now(),
                          );
                          if (t != null) setDialog(() => start = t);
                        },
                        child: Text(
                          start == null
                              ? 'Chọn giờ bắt đầu'
                              : start!.format(ctx),
                        ),
                      ),
                      OutlinedButton(
                        onPressed: () async {
                          final t = await showTimePicker(
                            context: ctx,
                            initialTime: end ?? TimeOfDay.now(),
                          );
                          if (t != null) setDialog(() => end = t);
                        },
                        child: Text(
                          end == null ? 'Chọn giờ kết thúc' : end!.format(ctx),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  const Text(
                    'Nhập giờ thật; không đoán giờ từ số tiết. Giờ ngoài lớp vẫn cần lịch rảnh/bận cá nhân.',
                  ),
                  if (error != null)
                    Text(error!, style: const TextStyle(color: Colors.red)),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Hủy'),
            ),
            FilledButton(
              onPressed: () async {
                if (start == null || end == null) {
                  setDialog(() => error = 'Chọn đủ giờ bắt đầu và kết thúc.');
                  return;
                }
                try {
                  await store.upsertSchoolLesson(
                    SchoolLesson(
                      id: 'lesson_${DateTime.now().microsecondsSinceEpoch}',
                      subject: subject,
                      weekday: weekday,
                      startTime: learningClock(
                        start!.hour * 60 + start!.minute,
                      ),
                      endTime: learningClock(end!.hour * 60 + end!.minute),
                    ),
                  );
                  if (ctx.mounted) Navigator.pop(ctx);
                } catch (e) {
                  setDialog(() => error = e.toString());
                }
              },
              child: const Text('Lưu giờ học'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _plan(MochiStore store) async {
    try {
      final plan = store.previewUnifiedPlan();
      await showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Xem trước lịch chung 7 ngày'),
          content: SizedBox(
            width: 700,
            height: math.min(560, MediaQuery.sizeOf(ctx).height * .58),
            child: ListView(
              children: [
                const Text(
                  'Một quỹ giờ cho tất cả môn. Giữ giờ lên lớp, giờ bận và nhiệm vụ đã khóa. Đây là xếp giờ theo ràng buộc, không tự sinh nội dung bài học.',
                ),
                const SizedBox(height: 12),
                for (final block in plan.blocks)
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.schedule_outlined),
                    title: Text(block.title),
                    subtitle: Text(
                      '${block.date} · ${block.startTime} · ${block.minutes} phút · ${block.subject}\n${block.reason}',
                    ),
                  ),
                if (plan.deferred.isNotEmpty) ...[
                  const Divider(),
                  const Text(
                    'Việc chưa được xếp / giữ nguyên',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  for (final d in plan.deferred)
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      title: Text(
                        store.tasks
                                .where((t) => t.id == d.taskId)
                                .firstOrNull
                                ?.title ??
                            'Nhiệm vụ',
                      ),
                      subtitle: Text(
                        '${d.reason}${d.remainingMinutes > 0 ? ' Còn ${d.remainingMinutes} phút.' : ''}',
                      ),
                    ),
                ],
                if (plan.blocks.isEmpty)
                  const Text(
                    'Chưa có phiên có thể xếp. Kiểm tra việc cần làm, giờ rảnh và tổng thời lượng học mỗi ngày.',
                  ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Để sau'),
            ),
            FilledButton(
              onPressed: plan.blocks.isEmpty
                  ? null
                  : () async {
                      try {
                        await store.acceptUnifiedPlan(plan);
                        if (ctx.mounted) Navigator.pop(ctx);
                      } catch (e) {
                        _error(e);
                      }
                    },
              child: const Text('Áp dụng lịch'),
            ),
          ],
        ),
      );
    } catch (e) {
      _error(e);
    }
  }

  
  Future<void> _importTimetableWithAI(MochiStore store) async {
    final textController = TextEditingController();
    bool isExtracting = false;
    String? error;
    List<Map<String, dynamic>>? previewLessons;
    XFile? pickedImage;
    String? imageBase64;

    await showDialog<void>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialog) => AlertDialog(
          title: const Text('Nhập thời khóa biểu bằng AI'),
          content: SizedBox(
            width: 560,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Dán văn bản hoặc bảng thời khóa biểu của trường/lớp. AI sẽ bóc tách môn, thứ và khung giờ để bạn xem trước trước khi lưu.',
                    style: TextStyle(fontSize: 13, color: MochiColors.muted),
                  ),
                  const SizedBox(height: 12),
                  if (previewLessons == null) ...[
                    if (pickedImage != null)
                      Container(
                        margin: const EdgeInsets.only(bottom: 12),
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: const Color(0xFFF1F5F9),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: const Color(0xFFCBD5E1)),
                        ),
                        child: Row(
                          children: [
                            const Icon(Icons.image_outlined, color: MochiColors.purple),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                pickedImage!.name,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13),
                              ),
                            ),
                            IconButton(
                              icon: const Icon(Icons.close, size: 18),
                              onPressed: () {
                                setDialog(() {
                                  pickedImage = null;
                                  imageBase64 = null;
                                });
                              },
                            ),
                          ],
                        ),
                      )
                    else ...[
                      Row(
                        children: [
                          Expanded(
                            child: OutlinedButton.icon(
                              onPressed: isExtracting ? null : () async {
                                final picker = ImagePicker();
                                final file = await picker.pickImage(source: ImageSource.gallery, maxWidth: 1600, maxHeight: 1600, imageQuality: 85);
                                if (file != null) {
                                  final bytes = await file.readAsBytes();
                                  setDialog(() {
                                    pickedImage = file;
                                    imageBase64 = 'data:image/jpeg;base64,' + base64Encode(bytes);
                                    error = null;
                                  });
                                }
                              },
                              icon: const Icon(Icons.photo_library_outlined, size: 18),
                              label: const Text('Chọn ảnh TKB'),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: OutlinedButton.icon(
                              onPressed: isExtracting ? null : () async {
                                final picker = ImagePicker();
                                final file = await picker.pickImage(source: ImageSource.camera, maxWidth: 1600, maxHeight: 1600, imageQuality: 85);
                                if (file != null) {
                                  final bytes = await file.readAsBytes();
                                  setDialog(() {
                                    pickedImage = file;
                                    imageBase64 = 'data:image/jpeg;base64,' + base64Encode(bytes);
                                    error = null;
                                  });
                                }
                              },
                              icon: const Icon(Icons.camera_alt_outlined, size: 18),
                              label: const Text('Chụp ảnh TKB'),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                    ],
                    TextField(
                      controller: textController,
                      maxLines: 4,
                      decoration: const InputDecoration(
                        labelText: 'Nội dung thời khóa biểu hoặc ghi chú',
                        hintText: 'Dán nội dung bảng lớp, hoặc chọn ảnh bên trên...',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    if (isExtracting) ...[
                      const SizedBox(height: 16),
                      const Row(
                        children: [
                          SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          ),
                          SizedBox(width: 12),
                          Text('AI đang bóc tách thời khóa biểu...'),
                        ],
                      ),
                    ],
                  ] else ...[
                    Text(
                      'Đã trích xuất ${previewLessons!.length} tiết học. Bạn có thể kiểm tra trước khi lưu:',
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 8),
                    Container(
                      constraints: const BoxConstraints(maxHeight: 280),
                      child: ListView.builder(
                        shrinkWrap: true,
                        itemCount: previewLessons!.length,
                        itemBuilder: (c, idx) {
                          final item = previewLessons![idx];
                          final wd = item['weekday'] as int? ?? 1;
                          final dayName = wd == 7 ? 'Chủ nhật' : 'Thứ ${wd + 1}';
                          return Card(
                            margin: const EdgeInsets.only(bottom: 6),
                            child: ListTile(
                              dense: true,
                              title: Text(item['subject']?.toString() ?? 'Môn học'),
                              subtitle: Text('$dayName · ${item['startTime']} - ${item['endTime']}'),
                              trailing: IconButton(
                                icon: const Icon(Icons.remove_circle_outline, size: 20),
                                onPressed: () {
                                  setDialog(() {
                                    previewLessons!.removeAt(idx);
                                  });
                                },
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                  if (error != null) ...[
                    const SizedBox(height: 12),
                    Text(error!, style: const TextStyle(color: Colors.red, fontSize: 13)),
                  ],
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Hủy'),
            ),
            if (previewLessons == null)
              FilledButton(
                onPressed: isExtracting
                    ? null
                    : () async {
                        final raw = textController.text.trim();
                        FocusManager.instance.primaryFocus?.unfocus();
                        if (raw.isEmpty && imageBase64 == null) {
                          setDialog(() => error = 'Vui lòng chọn ảnh hoặc dán nội dung thời khóa biểu.');
                          return;
                        }
                        setDialog(() {
                          isExtracting = true;
                          error = null;
                        });
                        try {
                          final res = await store.aiService.extractTimetable(
                            rawContent: raw.isNotEmpty ? raw : null,
                            imageDataUri: imageBase64,
                          );
                          setDialog(() {
                            isExtracting = false;
                            previewLessons = res;
                          });
                        } catch (e) {
                          setDialog(() {
                            isExtracting = false;
                            error = e.toString().replaceFirst('Bad state: ', '');
                          });
                        }
                      },
                child: const Text('Bóc tách với AI'),
              )
            else
              FilledButton(
                onPressed: previewLessons!.isEmpty
                    ? null
                    : () async {
                        try {
                          for (final p in previewLessons!) {
                            final lesson = SchoolLesson(
                              id: 'lesson_${DateTime.now().microsecondsSinceEpoch}_${p['weekday']}_${p['subject']}',
                              subject: p['subject']?.toString() ?? 'Môn học',
                              weekday: p['weekday'] as int? ?? 1,
                              startTime: p['startTime']?.toString() ?? '07:15',
                              endTime: p['endTime']?.toString() ?? '08:00',
                            );
                            await store.upsertSchoolLesson(lesson);
                          }
                          if (ctx.mounted) Navigator.pop(ctx);
                        } catch (e) {
                          setDialog(() => error = e.toString());
                        }
                      },
                child: const Text('Lưu vào thời khóa biểu'),
              ),
          ],
        ),
      ),
    );
  }

  Widget _progress(MochiStore store) => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      const Text(
        'Đánh dấu theo thực tế của bạn',
        style: TextStyle(fontWeight: FontWeight.w800, fontSize: 20),
      ),
      const SizedBox(height: 8),
      const Text(
        'Đây là tự đánh giá, không phải điểm năng lực chính thức. Chưa đánh dấu nghĩa là chưa có thông tin; ngày tháng không tự quyết định bạn đã học gì.',
      ),
      for (final course in store.learning.courses)
        Card(
          child: ExpansionTile(
            title: Text(course.subject),
            subtitle: Text(
              course.textbook.isEmpty ? 'Chưa chọn bộ sách' : course.textbook,
            ),
            trailing: IconButton(
              tooltip: 'Tài liệu và chủ đề ${course.subject}',
              icon: const Icon(Icons.edit_outlined),
              onPressed: () => _editCourse(store, course),
            ),
            children: [
              Padding(
                padding: const EdgeInsets.all(12),
                child: Text(
                  course.sourceLabel,
                  style: const TextStyle(
                    fontSize: 12,
                    color: MochiColors.muted,
                  ),
                ),
              ),
              if (course.topics.isEmpty)
                Padding(
                  padding: const EdgeInsets.all(12),
                  child: FilledButton.tonal(
                    onPressed: () => _editCourse(store, course),
                    child: const Text('Thêm chủ đề đang theo học'),
                  ),
                ),
              for (final topic in course.topics)
                Padding(
                  padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        topic.title,
                        style: const TextStyle(fontWeight: FontWeight.w700),
                      ),
                      const SizedBox(height: 6),
                      Wrap(
                        spacing: 6,
                        runSpacing: 6,
                        children: [
                          for (final item in const {
                            TopicReadiness.notStudied: 'Chưa học',
                            TopicReadiness.needsReview: 'Cần ôn',
                            TopicReadiness.confident: 'Tự đánh giá đã vững',
                          }.entries)
                            ChoiceChip(
                              label: Text(item.value),
                              selected:
                                  store.learning.readinessFor(topic.id) ==
                                  item.key,
                              onSelected: (on) => store.setTopicReadiness(
                                course.id,
                                topic.id,
                                on ? item.key : TopicReadiness.unknown,
                              ),
                            ),
                        ],
                      ),
                    ],
                  ),
                ),
            ],
          ),
        ),
    ],
  );
  Widget _agenda(MochiStore store) {
    final plan = store.learning.activePlan;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            FilledButton.icon(
              key: const ValueKey('learning-add-assignment'),
              onPressed: () => _assignment(store),
              icon: const Icon(Icons.add),
              label: const Text('Thêm bài / việc cần học'),
            ),
            OutlinedButton.icon(
              key: const ValueKey('learning-plan-all'),
              onPressed: () => _plan(store),
              icon: const Icon(Icons.calendar_view_week_outlined),
              label: const Text('Xếp lịch chung'),
            ),
          ],
        ),
        const SizedBox(height: 12),
        Text(
          'Ngân sách toàn bộ môn: ${store.dailyRoutine.preferredDailyMinutes} phút/ngày. Đổi trong lịch sinh hoạt, không nhân số phút này với số mục tiêu.',
          style: const TextStyle(color: MochiColors.muted),
        ),
        if (plan != null) ...[
          const SizedBox(height: 16),
          const Text(
            'Lịch đã áp dụng',
            style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18),
          ),
          for (final block in plan.blocks)
            if (store.tasks.any((t) => t.id == block.taskId && !t.isDone))
              Card(
                child: ListTile(
                  title: Text(block.title),
                  subtitle: Text(
                    '${block.date} · ${block.startTime} · ${block.minutes} phút · ${block.subject}\nĐã ghi nhận ${store.learning.completedMinutesForBlock(block.id)} phút',
                  ),
                  trailing: IconButton(
                    tooltip: 'Học phần này',
                    icon: const Icon(Icons.play_arrow_rounded),
                    onPressed: () {
                      final task = store.tasks.firstWhere(
                        (t) => t.id == block.taskId,
                      );
                      final data = task.toJson()
                        ..['durationMinutes'] = block.minutes;
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => FocusTimerScreen(
                            targetTask: TaskModel.fromJson(data),
                            learningBlockId: block.id,
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ),
        ],
        const SizedBox(height: 16),
        const Text(
          'Tất cả bài và nhiệm vụ',
          style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18),
        ),
        if (store.tasks.isEmpty)
          const Padding(
            padding: EdgeInsets.all(16),
            child: Text(
              'Thêm việc thật từ lớp hoặc mục tiêu để bắt đầu. Không tự tạo bài mẫu vào hồ sơ của bạn.',
            ),
          ),
        for (final task in store.tasks)
          Card(
            child: CheckboxListTile(
              value: task.isDone,
              onChanged: (v) => store.toggleTask(task.id, v ?? false),
              title: Text(task.title),
              subtitle: Text(
                '${task.subject} · ${task.durationMinutes} phút · ${task.kind == 'homework'
                    ? 'Bài được giao'
                    : task.kind == 'preparation'
                    ? 'Chuẩn bị bài'
                    : 'Học / ôn / luyện'}${task.dueAt == null ? ' · Chưa có hạn' : ' · Hạn ${task.dueAt!.day}/${task.dueAt!.month} ${learningClock(task.dueAt!.hour * 60 + task.dueAt!.minute)}'}',
              ),
            ),
          ),
      ],
    );
  }

  Widget _timetable(MochiStore store) => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      const Text(
        'Giờ học thực tế',
        style: TextStyle(fontWeight: FontWeight.w800, fontSize: 20),
      ),
      const SizedBox(height: 8),
      const Text(
        'Các khoảng này được loại khỏi giờ có thể tự học. Nhập giờ lớp và học thêm; phần nhận ảnh/file sẽ đi qua bước xem trước trước khi lưu.',
      ),
      const SizedBox(height: 12),
      Wrap(
        spacing: 8,
        runSpacing: 8,
        children: [
          FilledButton.icon(
          onPressed: () => _lesson(store),
          icon: const Icon(Icons.add),
          label: const Text('Thêm giờ lên lớp'),
        ),
        const SizedBox(width: 8),
        OutlinedButton.icon(
          onPressed: () => _importTimetableWithAI(store),
          icon: const Icon(Icons.auto_awesome),
          label: const Text('Nhập TKB bằng AI'),
        ),
      ],),
      for (final lesson
          in [...store.learning.timetable]..sort(
            (a, b) =>
                (a.weekday * 1440 + int.parse(a.startTime.replaceAll(':', '')))
                    .compareTo(
                      b.weekday * 1440 +
                          int.parse(b.startTime.replaceAll(':', '')),
                    ),
          ))
        Card(
          child: ListTile(
            title: Text(lesson.subject),
            subtitle: Text(
              '${lesson.weekday == 7 ? 'Chủ nhật' : 'Thứ ${lesson.weekday + 1}'} · ${lesson.startTime}–${lesson.endTime}',
            ),
            trailing: IconButton(
              tooltip: 'Xóa giờ học',
              icon: const Icon(Icons.delete_outline),
              onPressed: () async {
                final yes = await showDialog<bool>(
                  context: context,
                  builder: (ctx) => AlertDialog(
                    title: const Text('Xóa giờ học này?'),
                    content: Text(
                      '${lesson.subject} · ${lesson.startTime}–${lesson.endTime}',
                    ),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.pop(ctx, false),
                        child: const Text('Giữ lại'),
                      ),
                      FilledButton(
                        onPressed: () => Navigator.pop(ctx, true),
                        child: const Text('Xóa'),
                      ),
                    ],
                  ),
                );
                if (yes == true) await store.removeSchoolLesson(lesson.id);
              },
            ),
          ),
        ),
    ],
  );
  @override
  Widget build(BuildContext context) {
    final store = context.watch<MochiStore>();
    return DefaultTabController(
      length: 3,
      initialIndex: widget.initialTab,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Học tập cá nhân'),
          actions: [
            IconButton(
              tooltip: 'Thiết lập lớp và môn học',
              icon: const Icon(Icons.tune_rounded),
              onPressed: () => _setup(store),
            ),
          ],
          bottom: const TabBar(
            isScrollable: true,
            tabs: [
              Tab(text: 'Tiến độ môn'),
              Tab(text: 'Bài & lịch chung'),
              Tab(text: 'Thời khóa biểu'),
            ],
          ),
        ),
        body: Column(
          children: [
            if (store.learning.gradeLevel == null)
              Material(
                color: MochiColors.lavender,
                child: ListTile(
                  title: const Text('Chọn lớp và các môn bạn đang học'),
                  subtitle: const Text(
                    'Đánh dấu tiến độ một lần, cập nhật dần theo bài trên lớp.',
                  ),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => _setup(store),
                ),
              ),
            if (store.cloudService.hasActiveUser && !store.isCloudSynced)
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                child: Text(
                  'Thay đổi đang chờ đồng bộ hoặc cần kết nối lại.',
                  style: TextStyle(fontSize: 12, color: MochiColors.muted),
                ),
              ),
            Expanded(
              child: TabBarView(
                children: [_progress(store), _agenda(store), _timetable(store)],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
