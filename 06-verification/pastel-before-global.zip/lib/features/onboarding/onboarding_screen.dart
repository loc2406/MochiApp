import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../../core/database/mochi_store.dart';
import '../../core/theme/mochi_theme.dart';
import '../../core/theme/apple_glass_theme.dart';
import '../robot/robot_mascot_widget.dart';

class OnboardingScreen extends StatefulWidget {
  final VoidCallback onComplete;

  const OnboardingScreen({super.key, required this.onComplete});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final PageController _pageController = PageController();
  int _currentStep = 0;

  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _robotNameController = TextEditingController(text: 'Mochi');
  final TextEditingController _goalController = TextEditingController();
  
  String _gradeBand = 'THCS';
  String _selectedSubject = 'Toán';
  int _selectedColorHex = 0xFF50C9A7;

  final List<String> _gradeBands = ['Tiểu học', 'THCS', 'THPT', 'Đại học', 'Tự học'];
  final List<String> _subjects = ['Toán', 'Vật lý', 'Hóa học', 'Tiếng Anh', 'Ngữ văn', 'Tin học', 'Sinh học'];

  @override
  void dispose() {
    _pageController.dispose();
    _nameController.dispose();
    _robotNameController.dispose();
    _goalController.dispose();
    super.dispose();
  }

  void _nextPage() {
    HapticFeedback.selectionClick();
    if (_currentStep == 0 && _nameController.text.trim().isEmpty) {
      _nameController.text = 'Bạn nhỏ';
    }
    if (_currentStep == 1 && _goalController.text.trim().isEmpty) {
      _goalController.text = 'Chinh phục kỳ thi học kỳ';
    }

    if (_currentStep < 2) {
      _pageController.nextPage(
        duration: const Duration(milliseconds: 320),
        curve: Curves.easeOutCubic,
      );
      setState(() => _currentStep++);
    } else {
      _finishOnboarding();
    }
  }

  void _prevPage() {
    HapticFeedback.selectionClick();
    if (_currentStep > 0) {
      _pageController.previousPage(
        duration: const Duration(milliseconds: 320),
        curve: Curves.easeOutCubic,
      );
      setState(() => _currentStep--);
    }
  }

  Future<void> _finishOnboarding() async {
    final store = context.read<MochiStore>();
    store.changeRobotColor(_selectedColorHex);
    await store.completeOnboarding(
      learnerName: _nameController.text.trim(),
      gradeBand: _gradeBand,
      robotName: _robotNameController.text.trim().isEmpty ? 'Mochi' : _robotNameController.text.trim(),
      primaryGoal: _goalController.text.trim(),
      targetSubject: _selectedSubject,
    );
    widget.onComplete();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppleOS27Colors.systemBackground,
      body: SafeArea(
        child: Column(
          children: [
            // Apple OS27 Segmented Dynamic Step Pill
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
              child: Row(
                children: List.generate(3, (index) {
                  final isPassed = index <= _currentStep;
                  return Expanded(
                    child: Container(
                      height: 5,
                      margin: const EdgeInsets.symmetric(horizontal: 4),
                      decoration: BoxDecoration(
                        gradient: isPassed
                            ? const LinearGradient(
                                colors: [AppleOS27Colors.electricViolet, Color(0xFF9333EA)],
                              )
                            : null,
                        color: isPassed ? null : const Color(0xFFCBD5E1),
                        borderRadius: BorderRadius.circular(3),
                      ),
                    ),
                  );
                }),
              ),
            ),

            Expanded(
              child: PageView(
                controller: _pageController,
                physics: const NeverScrollableScrollPhysics(),
                children: [
                  _buildStep1LearnerInfo(),
                  _buildStep2GoalSetup(),
                  _buildStep3RobotCustomization(),
                ],
              ),
            ),

            // Bottom Floating Controls
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 8, 24, 20),
              child: Row(
                children: [
                  if (_currentStep > 0)
                    OutlinedButton(
                      onPressed: _prevPage,
                      style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                        side: const BorderSide(color: Color(0xFFCBD5E1)),
                      ),
                      child: const Text('Quay lại', style: TextStyle(color: AppleOS27Colors.textPrimary, fontWeight: FontWeight.w700)),
                    ),
                  if (_currentStep > 0) const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: _nextPage,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppleOS27Colors.deepNavy,
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                        elevation: 0,
                      ),
                      child: Text(
                        _currentStep == 2 ? 'Bắt đầu hành trình cùng Mochi' : 'Tiếp tục',
                        style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: Colors.white),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStep1LearnerInfo() {
    return LayoutBuilder(
      builder: (context, constraints) {
        final mascotSize = (constraints.maxHeight * 0.22).clamp(70.0, 130.0);

        return SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 10),
              Center(
                child: RobotMascotWidget(
                  size: mascotSize,
                  primaryColor: Color(_selectedColorHex),
                ),
              ),
              const SizedBox(height: 16),
              const Text(
                'Chào mừng bạn đến với Mochi!',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: AppleOS27Colors.textPrimary, letterSpacing: -0.3),
              ),
              const SizedBox(height: 4),
              const Text(
                'Người bạn robot AI thông minh đồng hành cùng việc học mỗi ngày.',
                style: TextStyle(fontSize: 13, color: AppleOS27Colors.textSecondary),
              ),
              const SizedBox(height: 20),
              const Text(
                'Tên hoặc biệt danh của bạn:',
                style: TextStyle(fontWeight: FontWeight.w700, color: AppleOS27Colors.textPrimary, fontSize: 13.5),
              ),
              const SizedBox(height: 8),
              TextField(
                controller: _nameController,
                decoration: InputDecoration(
                  hintText: 'Ví dụ: Minh Khang, Lan Anh...',
                  prefixIcon: const Icon(Icons.person_outline_rounded, color: AppleOS27Colors.textSecondary),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
                ),
              ),
              const SizedBox(height: 18),
              const Text(
                'Cấp học hiện tại:',
                style: TextStyle(fontWeight: FontWeight.w700, color: AppleOS27Colors.textPrimary, fontSize: 13.5),
              ),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: _gradeBands.map((grade) {
                  final isSelected = _gradeBand == grade;
                  return ChoiceChip(
                    label: Text(grade),
                    selected: isSelected,
                    selectedColor: AppleOS27Colors.electricViolet,
                    labelStyle: TextStyle(
                      color: isSelected ? Colors.white : AppleOS27Colors.textPrimary,
                      fontWeight: FontWeight.w700,
                      fontSize: 12.5,
                    ),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    onSelected: (val) {
                      if (val) {
                        HapticFeedback.selectionClick();
                        setState(() => _gradeBand = grade);
                      }
                    },
                  );
                }).toList(),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildStep2GoalSetup() {
    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 16),
          const Text(
            'Mục tiêu học tập lớn của bạn',
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: AppleOS27Colors.textPrimary, letterSpacing: -0.3),
          ),
          const SizedBox(height: 4),
          const Text(
            'Mochi AI sẽ phân rã mục tiêu này thành những bước nhỏ khả thi.',
            style: TextStyle(fontSize: 13, color: AppleOS27Colors.textSecondary),
          ),
          const SizedBox(height: 20),
          const Text(
            'Môn học bạn muốn tập trung nhất:',
            style: TextStyle(fontWeight: FontWeight.w700, color: AppleOS27Colors.textPrimary, fontSize: 13.5),
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: _subjects.map((subj) {
              final isSelected = _selectedSubject == subj;
              return ChoiceChip(
                label: Text(subj),
                selected: isSelected,
                selectedColor: AppleOS27Colors.electricViolet,
                labelStyle: TextStyle(
                  color: isSelected ? Colors.white : AppleOS27Colors.textPrimary,
                  fontWeight: FontWeight.w700,
                  fontSize: 12.5,
                ),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                onSelected: (val) {
                  if (val) {
                    HapticFeedback.selectionClick();
                    setState(() => _selectedSubject = subj);
                  }
                },
              );
            }).toList(),
          ),
          const SizedBox(height: 20),
          const Text(
            'Mục tiêu cụ thể:',
            style: TextStyle(fontWeight: FontWeight.w700, color: AppleOS27Colors.textPrimary, fontSize: 13.5),
          ),
          const SizedBox(height: 8),
          TextField(
            controller: _goalController,
            maxLines: 2,
            decoration: InputDecoration(
              hintText: 'Ví dụ: Đạt điểm 9 môn Toán học kỳ này, Thuộc 300 từ vựng IELTS...',
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStep3RobotCustomization() {
    return LayoutBuilder(
      builder: (context, constraints) {
        final mascotSize = (constraints.maxHeight * 0.24).clamp(80.0, 140.0);

        return SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 10),
              Center(
                child: RobotMascotWidget(
                  size: mascotSize,
                  primaryColor: Color(_selectedColorHex),
                ),
              ),
              const SizedBox(height: 16),
              const Text(
                'Tùy chỉnh người bạn Robot',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: AppleOS27Colors.textPrimary, letterSpacing: -0.3),
              ),
              const SizedBox(height: 4),
              const Text(
                'Đặt tên và chọn sắc màu đồng hành cùng bạn.',
                style: TextStyle(fontSize: 13, color: AppleOS27Colors.textSecondary),
              ),
              const SizedBox(height: 18),
              const Text(
                'Tên Robot:',
                style: TextStyle(fontWeight: FontWeight.w700, color: AppleOS27Colors.textPrimary, fontSize: 13.5),
              ),
              const SizedBox(height: 8),
              TextField(
                controller: _robotNameController,
                decoration: InputDecoration(
                  hintText: 'Mochi, Pi, Bobo, Astra...',
                  prefixIcon: const Icon(Icons.smart_toy_outlined, color: AppleOS27Colors.textSecondary),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
                ),
              ),
              const SizedBox(height: 18),
              const Text(
                'Sắc màu chủ đạo:',
                style: TextStyle(fontWeight: FontWeight.w700, color: AppleOS27Colors.textPrimary, fontSize: 13.5),
              ),
              const SizedBox(height: 10),
              Wrap(
                spacing: 12,
                runSpacing: 10,
                children: MochiColors.robotPalettes.map((c) {
                  final isSelected = _selectedColorHex == c.toARGB32();
                  return GestureDetector(
                    onTap: () {
                      HapticFeedback.selectionClick();
                      setState(() => _selectedColorHex = c.toARGB32());
                    },
                    child: Container(
                      width: 38,
                      height: 38,
                      decoration: BoxDecoration(
                        color: c,
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: isSelected ? AppleOS27Colors.deepNavy : Colors.white,
                          width: isSelected ? 3.5 : 2,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withValues(alpha: 0.12),
                            blurRadius: 4,
                            offset: const Offset(0, 2),
                          ),
                        ],
                      ),
                    ),
                  );
                }).toList(),
              ),
            ],
          ),
        );
      },
    );
  }
}

