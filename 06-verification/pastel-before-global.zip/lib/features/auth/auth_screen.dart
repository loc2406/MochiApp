import '../../core/models/mochi_models.dart';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/database/mochi_store.dart';
import '../../core/theme/mochi_theme.dart';
import '../robot/robot_mascot_widget.dart';

class AuthScreen extends StatefulWidget {
  final VoidCallback onAuthenticated;
  final bool isSkippable;

  const AuthScreen({
    super.key,
    required this.onAuthenticated,
    this.isSkippable = true,
  });

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  bool _isSignUp = false;
  bool _isLoading = false;
  final TextEditingController _emailCtrl = TextEditingController();
  final TextEditingController _passCtrl = TextEditingController();
  String? _errorMessage;

  @override
  void dispose() {
    _emailCtrl.dispose();
    _passCtrl.dispose();
    super.dispose();
  }

  void _handleSubmit() async {
    FocusManager.instance.primaryFocus?.unfocus();
    final email = _emailCtrl.text.trim();
    final pass = _passCtrl.text.trim();

    if (email.isEmpty || !email.contains('@')) {
      setState(() => _errorMessage = 'Vui lòng nhập địa chỉ email hợp lệ.');
      return;
    }
    if (pass.length < 6) {
      setState(() => _errorMessage = 'Mật khẩu phải từ 6 ký tự trở lên.');
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    final store = context.read<MochiStore>();
    String? err;

    if (_isSignUp) {
      err = await store.cloudService.signUp(email: email, password: pass);
    } else {
      err = await store.cloudService.signIn(email: email, password: pass);
    }

    if (!mounted) return;
    if (err == null && !store.cloudService.hasActiveUser) {
      setState(() {
        _isLoading = false;
        _errorMessage = 'Kiểm tra email để xác nhận tài khoản, sau đó đăng nhập để đồng bộ.';
      });
      return;
    }
    if (err == null) {
      await store.refreshCloudAuth();
      if (!mounted) return;
      setState(() => _isLoading = false);
      if (store.syncError != null) {
        setState(() => _errorMessage = store.syncError);
        return;
      }
      widget.onAuthenticated();
    } else {
      setState(() {
        _isLoading = false;
        _errorMessage = err;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: MochiColors.background,
      appBar: AppBar(
        title: Text(
          _isSignUp ? 'Tạo tài khoản học tập' : 'Đăng nhập tài khoản',
          style: const TextStyle(fontWeight: FontWeight.w800),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: RobotMascotWidget(
                  size: 100,
                  emotion: RobotEmotion.happy,
                ),
              ),
              const SizedBox(height: 20),
              Center(
                child: Text(
                  _isSignUp
                      ? 'Đăng ký lưu trữ đám mây'
                      : 'Chào mừng bạn quay lại!',
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                    color: MochiColors.navy,
                  ),
                ),
              ),
              const SizedBox(height: 6),
              const Center(
                child: Text(
                  'Dữ liệu mục tiêu, bài tập và sao sẽ được đồng bộ tự động an toàn qua máy chủ đám mây.',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 13, color: MochiColors.muted),
                ),
              ),
              const SizedBox(height: 24),

              if (_errorMessage != null)
                Container(
                  padding: const EdgeInsets.all(12),
                  margin: const EdgeInsets.only(bottom: 16),
                  decoration: BoxDecoration(
                    color: Colors.red.shade50,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: Colors.red.shade200),
                  ),
                  child: Row(
                    children: [
                      const Icon(
                        Icons.error_outline,
                        color: MochiColors.danger,
                        size: 20,
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          _errorMessage!,
                          style: const TextStyle(
                            color: MochiColors.danger,
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

              const Text(
                'Địa chỉ Email:',
                style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
              ),
              const SizedBox(height: 6),
              TextField(
                controller: _emailCtrl,
                keyboardType: TextInputType.emailAddress,
                decoration: const InputDecoration(
                  hintText: 'hocsinh@example.com',
                  prefixIcon: Icon(
                    Icons.email_outlined,
                    color: MochiColors.muted,
                  ),
                ),
              ),
              const SizedBox(height: 16),
              const Text(
                'Mật khẩu:',
                style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
              ),
              const SizedBox(height: 6),
              TextField(
                controller: _passCtrl,
                obscureText: true,
                decoration: const InputDecoration(
                  hintText: 'Tối thiểu 6 ký tự',
                  prefixIcon: Icon(
                    Icons.lock_outline,
                    color: MochiColors.muted,
                  ),
                ),
              ),
              const SizedBox(height: 24),

              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _isLoading ? null : _handleSubmit,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: MochiColors.navy,
                    padding: const EdgeInsets.symmetric(vertical: 15),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                  ),
                  child: _isLoading
                      ? const SizedBox(
                          width: 22,
                          height: 22,
                          child: CircularProgressIndicator(
                            color: Colors.white,
                            strokeWidth: 2,
                          ),
                        )
                      : Text(
                          _isSignUp
                              ? 'Tạo tài khoản & Đồng bộ'
                              : 'Đăng nhập ngay',
                          style: const TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                ),
              ),
              const SizedBox(height: 12),

              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    _isSignUp ? 'Đã có tài khoản?' : 'Chưa có tài khoản?',
                    style: const TextStyle(
                      fontSize: 13,
                      color: MochiColors.muted,
                    ),
                  ),
                  TextButton(
                    onPressed: () => setState(() {
                      _isSignUp = !_isSignUp;
                      _errorMessage = null;
                    }),
                    child: Text(
                      _isSignUp ? 'Đăng nhập' : 'Đăng ký ngay',
                      style: const TextStyle(
                        fontWeight: FontWeight.w700,
                        color: MochiColors.purple,
                      ),
                    ),
                  ),
                ],
              ),

              if (widget.isSkippable) ...[
                const SizedBox(height: 16),
                Center(
                  child: TextButton.icon(
                    onPressed: widget.onAuthenticated,
                    icon: const Icon(Icons.arrow_forward, size: 16),
                    label: const Text(
                      'Bỏ qua & Dùng thử trực tiếp',
                      style: TextStyle(fontWeight: FontWeight.w600),
                    ),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
