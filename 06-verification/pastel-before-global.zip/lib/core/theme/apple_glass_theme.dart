import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class AppleOS27Colors {
  // Deep Space System Backgrounds
  static const Color systemBackground = Color(0xFFF2F5FA);
  static const Color darkSpace = Color(0xFF0F172A);
  static const Color deepNavy = Color(0xFF13233D);
  static const Color cardSurface = Colors.white;
  static const Color glassSurface = Color(
    0xB8FFFFFF,
  ); // 72% opacity frosted white
  static const Color glassDark = Color(0xB81E293B);

  // Apple Futuristic Accents (OS27 Vibrant Spectrum)
  static const Color electricViolet = Color(0xFF7C3AED); // Primary accent
  static const Color cupertinoBlue = Color(0xFF2563EB);
  static const Color neonEmerald = Color(0xFF10B981);
  static const Color cyberAmber = Color(0xFFF59E0B);
  static const Color sunsetCoral = Color(0xFFF43F5E);
  static const Color oceanCyan = Color(0xFF06B6D4);

  // Preset definitions for Deep Personalization
  static const Map<String, Color> presetColors = {
    "electricViolet": electricViolet,
    "cupertinoBlue": cupertinoBlue,
    "neonEmerald": neonEmerald,
    "cyberAmber": cyberAmber,
    "sunsetCoral": sunsetCoral,
    "oceanCyan": oceanCyan,
  };

  static const Map<String, String> presetNames = {
    "electricViolet": "Electric Violet",
    "cupertinoBlue": "Xanh dương",
    "neonEmerald": "Neon Emerald",
    "cyberAmber": "Cyber Amber",
    "sunsetCoral": "Sunset Coral",
    "oceanCyan": "Ocean Cyan",
  };

  static Color accentFor(String? presetId) {
    return presetColors[presetId] ?? electricViolet;
  }

  // Typography Colors
  static const Color textPrimary = Color(0xFF0F172A);
  static const Color textSecondary = Color(0xFF64748B);
  static const Color textTertiary = Color(0xFF94A3B8);

  // Borders & Specular Lines
  static const Color glassBorder = Color(0x33FFFFFF);
  static const Color hairlineBorder = Color(0x1F000000);
}

class FrostedGlassCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final EdgeInsetsGeometry? margin;
  final double borderRadius;
  final double blurSigma;
  final Color? backgroundColor;
  final Color? borderColor;
  final VoidCallback? onTap;

  const FrostedGlassCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.margin,
    this.borderRadius = 22,
    this.blurSigma = 16,
    this.backgroundColor,
    this.borderColor,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    Widget card = ClipRRect(
      borderRadius: BorderRadius.circular(borderRadius),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: blurSigma, sigmaY: blurSigma),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            color: backgroundColor ?? Colors.white.withValues(alpha: 0.82),
            borderRadius: BorderRadius.circular(borderRadius),
            border: Border.all(
              color: borderColor ?? Colors.white.withValues(alpha: 0.6),
              width: 1.0,
            ),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFF0F172A).withValues(alpha: 0.05),
                blurRadius: 20,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: child,
        ),
      ),
    );

    if (margin != null) {
      card = Padding(padding: margin!, child: card);
    }

    if (onTap != null) {
      return GestureDetector(
        onTap: () {
          HapticFeedback.selectionClick();
          onTap!();
        },
        child: card,
      );
    }

    return card;
  }
}

class ApplePillBadge extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final Color? textColor;

  const ApplePillBadge({
    super.key,
    required this.icon,
    required this.label,
    required this.color,
    this.textColor,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withValues(alpha: 0.25), width: 0.8),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 14, color: color),
          const SizedBox(width: 4),
          Text(
            label,
            style: TextStyle(
              color: textColor ?? color,
              fontWeight: FontWeight.w700,
              fontSize: 12,
              letterSpacing: 0.2,
            ),
          ),
        ],
      ),
    );
  }
}
