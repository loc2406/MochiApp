import 'package:flutter/material.dart';

class MochiColors {
  // Brand Dark Blue & Navy
  static const Color navy = Color(0xFF172B49);
  static const Color navy2 = Color(0xFF243D60);
  static const Color ink = Color(0xFF172C4C);
  static const Color muted = Color(0xFF71809A);

  // Accent Colors
  static const Color purple = Color(0xFF7964D9);
  static const Color purple2 = Color(0xFF9A84F0);
  static const Color lavender = Color(0xFFF0EDFF);
  static const Color softBlue = Color(0xFFDFF0FF);
  static const Color background = Color(0xFFEDF3FB);
  static const Color surface = Color(0xFFFFFFFF);
  static const Color border = Color(0xFFE1E9F4);

  // Status & Gamification
  static const Color green = Color(0xFF45BD9A);
  static const Color yellow = Color(0xFFFFD76B);
  static const Color starGold = Color(0xFFFFB800);
  static const Color pink = Color(0xFFF58CC9);
  static const Color orange = Color(0xFFFF8B60);
  static const Color cyan = Color(0xFF4DD0E1);
  static const Color danger = Color(0xFFE53935);

  // Robot custom palettes
  static const List<Color> robotPalettes = [
    Color(0xFF50C9A7),
    Color(0xFF6B9CF7),
    Color(0xFFFFD56B),
    Color(0xFFF48BC8),
    Color(0xFFA48AF5),
    Color(0xFFB8C2D1),
    Color(0xFFFFAD8B),
    Color(0xFF7ED8E8),
  ];
}

class MochiTheme {
  static ThemeData get lightTheme {
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.light,
      primaryColor: MochiColors.navy,
      scaffoldBackgroundColor: MochiColors.background,
      colorScheme: ColorScheme.fromSeed(
        seedColor: MochiColors.purple,
        primary: MochiColors.navy,
        secondary: MochiColors.purple,
        surface: MochiColors.surface,
        error: MochiColors.danger,
      ),
      fontFamily: 'Inter',
      cardTheme: CardThemeData(
        color: MochiColors.surface,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: const BorderSide(color: MochiColors.border, width: 1.2),
        ),
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: MochiColors.navy,
        foregroundColor: Colors.white,
        elevation: 0,
        centerTitle: false,
        titleTextStyle: TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.w700,
          color: Colors.white,
          letterSpacing: 0.2,
        ),
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: Colors.white,
        selectedItemColor: MochiColors.purple,
        unselectedItemColor: MochiColors.muted,
        type: BottomNavigationBarType.fixed,
        elevation: 8,
        selectedLabelStyle: TextStyle(
          fontWeight: FontWeight.w700,
          fontSize: 11,
        ),
        unselectedLabelStyle: TextStyle(
          fontWeight: FontWeight.w500,
          fontSize: 11,
        ),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: MochiColors.navy,
          foregroundColor: Colors.white,
          elevation: 0,
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
          textStyle: const TextStyle(fontWeight: FontWeight.w600, fontSize: 15),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: Colors.white,
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 16,
          vertical: 14,
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: MochiColors.border),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: MochiColors.border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: MochiColors.purple, width: 2),
        ),
      ),
    );
  }
}
